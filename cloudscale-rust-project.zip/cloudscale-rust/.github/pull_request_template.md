## What changed?

Describe the feature, bug fix or documentation update and linked issue.

## Evidence

- [ ] `cargo fmt --all -- --check`
- [ ] `cargo clippy --workspace --all-targets -- -D warnings`
- [ ] `cargo test --workspace --all-targets --locked`
- [ ] `python3 scripts/verify.py --ci`
- [ ] Added or updated tests, operational docs and release notes as applicable

## Safety

- Did any change affect cost limits, min/max bounds, idempotency, leases, security or rollback?
- Was a failure/partial failure scenario tested?
- Are metrics samples free of personal data and secrets?
- Is any third-party code licensed and attributed?

## Authorship disclosure

Estimate AI-generated code fraction for THIS PR, with any human edits or review.

## Reviewer notes

List limitations, uncertainty, and things that still need external verification.
