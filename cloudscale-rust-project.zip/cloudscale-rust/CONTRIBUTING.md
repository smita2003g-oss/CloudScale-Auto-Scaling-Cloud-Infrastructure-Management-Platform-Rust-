# Contributing to CloudScale

CloudScale is currently a small Rust reference implementation, not a mature production project. The goal is clear, testable changes to scaling safety and operational correctness.

1. Open a genuine issue with reproduction or problem statement when useful.
2. Create a normal branch and make incremental commits using your own real identity.
3. Explain the risk of changes affecting costs, state, leases, security or decisions.
4. Add unit/integration tests and update docs with any new API behavior.
5. Run `cargo fmt`, Clippy, tests and verification scripts on a Rust-capable machine.
6. Open a real pull request, attach logs/CI links and request human review.
7. Disclose estimated AI contribution; do not submit copied proprietary source.

All contributors must have permission to license their contributions to this project. Never upload company code, cloud credentials, customer logs or personal information without authorization. Follow the project's MIT license and all dependencies' licenses.

**Authorship:** A commit's author must be the real person or automation that actually made it. Preserve timestamps, commit history and reviewers truthfully. It is unacceptable to backdate, impersonate authors or manufacture GitHub PRs to meet an external eligibility checklist.
