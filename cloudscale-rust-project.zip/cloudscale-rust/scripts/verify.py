#!/usr/bin/env python3
"""Static, reproducible repository audit (not a Rust compiler or test runner).

Checks and counts tracked source files, Cargo manifests, SQL schema, Rust
bracket/string balance, Git integrity and SHA-256 hashes. The caller can
optionally emit machine-readable JSON. An unrelated POSIX/awk LOC counter
is provided in verify_independent.sh for cross-checking.
"""

import argparse
import hashlib
import json
import pathlib
import re
import shutil
import sqlite3
import subprocess
import sys
import tomllib
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parent.parent


def git(*args):
    return subprocess.run(["git", "-C", str(ROOT), *args],
                          capture_output=True, text=True, check=True).stdout.strip()


def is_balanced_rust(text):
    """Basic lexical delimiter check; NOT Rust grammar validation."""
    stack = []
    pairs = {')': '(', ']': '[', '}': '{'}
    i = 0
    while i < len(text):
        if text.startswith('//', i):
            j = text.find('\n', i)
            i = len(text) if j == -1 else j + 1
            continue
        if text.startswith('/*', i):
            depth = 1
            i += 2
            while i < len(text) and depth:
                if text.startswith('/*', i):
                    depth += 1
                    i += 2
                elif text.startswith('*/', i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
            if depth:
                return False
            continue
        # Rust raw string literals r"..." and r#"..."#.
        if text[i] == 'r' and (i == 0 or not (text[i-1].isalnum() or text[i-1] == '_')):
            m = re.match(r'r(#{0,16})"', text[i:])
            if m:
                terminator = '"' + m.group(1)
                j = text.find(terminator, i + len(m.group(0)))
                if j == -1:
                    return False
                i = j + len(terminator)
                continue
        if text[i] == '"':
            i += 1
            while i < len(text):
                if text[i] == '\\':
                    i += 2
                    continue
                if text[i] == '"':
                    i += 1
                    break
                i += 1
            else:
                return False
            continue
        ch = text[i]
        if ch in '([{':
            stack.append(ch)
        elif ch in ')]}':
            if not stack or stack.pop() != pairs[ch]:
                return False
        i += 1
    return not stack


def schema_check():
    schema = (ROOT / 'migrations/0001_init.sql').read_text()
    connection = sqlite3.connect(':memory:')
    try:
        connection.executescript(schema)
        names = {r[0] for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        required = {'fleets','policies','metric_samples','decisions','controller_leases','audit_events'}
        if not required.issubset(names):
            raise ValueError(f'missing SQLite tables: {sorted(required - names)}')
        # The repository depends on SQLite's JSON1 functions for audit reads.
        if connection.execute("SELECT json_extract(json_object('ok',1),'$.ok')").fetchone()[0] != 1:
            raise ValueError('SQLite JSON functions unavailable')
        # Parse the same audit SQL expression used by the Rust storage layer.
        iso = connection.execute("SELECT strftime('%Y-%m-%dT%H:%M:%fZ',1761787200000 / 1000.0,'unixepoch')").fetchone()[0]
        if not iso or not iso.endswith('Z'):
            raise ValueError('SQLite datetime formatter unavailable')
        return {'ok': True, 'tables': sorted(names)}
    finally:
        connection.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', help='write a JSON verification report to this path')
    parser.add_argument('--ci', action='store_true', help='exit nonzero on static check failure')
    args = parser.parse_args()

    tracked = git('ls-files', '-z')
    # subprocess with text=True preserves NUL separators.
    paths = sorted(p for p in tracked.split('\0') if p)
    rust = [p for p in paths if p.endswith('.rs')]
    cargo = [p for p in paths if p.endswith('Cargo.toml')]
    documents = [p for p in paths if p.endswith('.md')]
    failures = []
    hashes = {}
    rust_lines = 0
    substantive_lines = 0
    test_cases = 0
    broken_delimiters = []

    for rel in paths:
        f = ROOT / rel
        if not f.is_file():
            failures.append(f'missing tracked file: {rel}')
            continue
        data = f.read_bytes()
        hashes[rel] = hashlib.sha256(data).hexdigest()
        if rel in rust:
            decoded = data.decode('utf-8')
            rust_lines += len(decoded.splitlines())
            substantive_lines += sum(bool(line.strip()) for line in decoded.splitlines())
            test_cases += len(re.findall(r'#\[\s*(?:tokio::)?test\s*\]', decoded))
            if not is_balanced_rust(decoded):
                broken_delimiters.append(rel)

    for rel in cargo:
        try:
            with (ROOT / rel).open('rb') as fp:
                tomllib.load(fp)
        except Exception as exc:
            failures.append(f'invalid Cargo TOML in {rel}: {exc}')

    try:
        schema = schema_check()
    except Exception as exc:
        schema = {'ok': False, 'error': str(exc)}
        failures.append(f'invalid SQLite schema: {exc}')

    for path in [
        'README.md', 'LICENSE', 'AI_DISCLOSURE.md', 'CONTRIBUTING.md',
        '.github/workflows/ci.yml','.github/pull_request_template.md',
        '.github/ISSUE_TEMPLATE/bug_report.yml','.github/ISSUE_TEMPLATE/feature_request.yml',
        'compose.yaml','Dockerfile','docs/ELIGIBILITY.md','docs/TEST_PLAN.md',
    ]:
        if path not in paths:
            failures.append(f'missing tracked project context: {path}')

    if broken_delimiters:
        failures.append(f'Rust lexical delimiter mismatch in: {broken_delimiters}')
    if rust_lines == 0 or test_cases == 0:
        failures.append('No Rust source or declared test cases found')

    try:
        git('fsck', '--full')
        git_integrity = True
    except subprocess.CalledProcessError as exc:
        git_integrity = False
        failures.append(f'Git fsck failed: {exc.stderr}')

    commit_count = int(git('rev-list', '--count', 'HEAD'))
    report = {
        'project': 'CloudScale (Rust simulation MVP)',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'git_head': git('rev-parse', 'HEAD'),
        'git_commits': commit_count,
        'tracked_files': len(paths),
        'rust_source_files': len(rust),
        'rust_physical_lines': rust_lines,
        'rust_nonblank_lines': substantive_lines,
        'rust_declared_test_functions': test_cases,
        'markdown_files': len(documents),
        'cargo_manifest_files': len(cargo),
        'static_delimiter_check': not broken_delimiters,
        'cargo_toml_parsed': not any('Cargo TOML' in msg for msg in failures),
        'sqlite_schema_test': schema,
        'git_fsck': git_integrity,
        'rust_compiler_present': bool(shutil.which('rustc')),
        'cargo_present': bool(shutil.which('cargo')),
        'rust_compilation_executed_by_this_script': False,
        'rust_tests_executed_by_this_script': False,
        'line_target_100000_met': rust_lines >= 100_000,
        'mostly_human_written_requirement_met': False,
        'actual_github_pull_requests_verified': False,
        'ai_generated_initial_estimate_pct': '95-100',
        'checks_failed': failures,
        'tracked_file_sha256': hashes,
    }
    print(json.dumps({k:v for k,v in report.items() if k != 'tracked_file_sha256'}, indent=2))
    if args.report:
        out = pathlib.Path(args.report)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    if failures and args.ci:
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
