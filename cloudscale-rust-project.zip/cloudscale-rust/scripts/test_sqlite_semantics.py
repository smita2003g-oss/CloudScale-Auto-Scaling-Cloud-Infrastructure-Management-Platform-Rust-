#!/usr/bin/env python3
"""Exercise SQL semantics independently using Python's SQLite, not Rust tests.

This probes the migration and exact lease, uniqueness and compare-and-swap
SQL shapes. Passing does NOT prove that the Rust SQLx application compiles.
"""

import json
import pathlib
import sqlite3
import uuid

ROOT = pathlib.Path(__file__).resolve().parent.parent

def check():
    db = sqlite3.connect(":memory:")
    db.execute('PRAGMA foreign_keys=ON')
    db.executescript((ROOT / 'migrations/0001_init.sql').read_text())
    fleet_id = str(uuid.uuid4())
    initial = {"id": fleet_id, "version": 0, "desired_replicas": 2}
    db.execute('INSERT INTO fleets (id,name,state_json,version,created_at_ms) VALUES (?,?,?,?,?)',
               (fleet_id,'test-prod',json.dumps(initial),0,1))
    db.execute('INSERT INTO policies (fleet_id,policy_json,revision) VALUES (?,?,?)',
               (fleet_id,'{}',1))

    lease_sql = ('INSERT INTO controller_leases (fleet_id,owner_id,expires_at_ms) VALUES (?,?,?) '
                 'ON CONFLICT(fleet_id) DO UPDATE SET owner_id=excluded.owner_id,'
                 'expires_at_ms=excluded.expires_at_ms WHERE controller_leases.expires_at_ms<? '
                 'OR controller_leases.owner_id=excluded.owner_id')
    assert db.execute(lease_sql,(fleet_id,'owner-a',1000,0)).rowcount == 1
    assert db.execute(lease_sql,(fleet_id,'owner-b',1000,0)).rowcount == 0
    assert db.execute(lease_sql,(fleet_id,'owner-b',2000,1001)).rowcount == 1
    assert db.execute('SELECT owner_id FROM controller_leases WHERE fleet_id=?',(fleet_id,)).fetchone()[0]=='owner-b'

    key = f'{fleet_id}:1:{uuid.uuid4()}'
    decision_sql = ('INSERT INTO decisions '
                    '(id,fleet_id,decision_key,decision_json,changed,created_at_ms) '
                    'VALUES (?,?,?,?,?,?) ON CONFLICT(decision_key) DO NOTHING')
    def decide(k):
        return db.execute(decision_sql,(str(uuid.uuid4()),fleet_id,k,'{}',1,100)).rowcount
    assert decide(key) == 1
    assert decide(key) == 0
    assert db.execute('UPDATE fleets SET version=version+1,state_json=? WHERE id=? AND version=?',
                      (json.dumps({"version":1}),fleet_id,0)).rowcount == 1
    assert db.execute('UPDATE fleets SET version=version+1,state_json=? WHERE id=? AND version=?',
                      ('{}',fleet_id,0)).rowcount == 0

    # Policy replacement must be guarded by expected revision.
    assert db.execute('UPDATE policies SET revision=2 WHERE fleet_id=? AND revision=1',(fleet_id,)).rowcount == 1
    assert db.execute('UPDATE policies SET revision=3 WHERE fleet_id=? AND revision=1',(fleet_id,)).rowcount == 0

    # Decision+state changes should either both survive COMMIT or both be lost.
    baseline = db.execute('SELECT count(*) FROM decisions').fetchone()[0]
    db.commit()
    db.execute('BEGIN')
    decide(f'{fleet_id}:2:{uuid.uuid4()}')
    db.execute('UPDATE fleets SET version=version+1 WHERE id=?',(fleet_id,))
    db.rollback()
    assert db.execute('SELECT count(*) FROM decisions').fetchone()[0] == baseline
    assert db.execute('SELECT version FROM fleets WHERE id=?',(fleet_id,)).fetchone()[0] == 1

    # Rust audit SQL uses JSON1 + fractional UTC timestamp conversion.
    db.execute('INSERT INTO audit_events (id,fleet_id,category,actor,detail,recorded_at_ms) VALUES (?,?,?,?,?,?)',
               (str(uuid.uuid4()),fleet_id,'test','verifier','details',1_767_187_000_123))
    rows=db.execute("SELECT json_object('id',id,'fleet_id',fleet_id,'category',category,'actor',actor,'detail',detail,'recorded_at',strftime('%Y-%m-%dT%H:%M:%fZ',recorded_at_ms/1000.0,'unixepoch')) FROM audit_events").fetchall()
    events=[json.loads(row[0]) for row in rows]
    assert len(events)==1
    assert events[0]['recorded_at'].endswith('Z')
    assert events[0]['category']=='test'
    db.close()
    print('PASS: SQLite migration, lease exclusivity, decision dedupe, CAS, rollback and audit JSON')

if __name__=='__main__':
    check()
