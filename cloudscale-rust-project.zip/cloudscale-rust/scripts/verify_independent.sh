#!/usr/bin/env bash
# Independent POSIX-based LOC check. Does not call the Python audit script.
set -euo pipefail
cd "$(dirname "$0")/.."
files=0
lines=0
tests=0
while IFS= read -r file; do
  [[ -z "$file" ]] && continue
  files=$((files + 1))
  n=$(awk 'END {print NR}' "$file")
  lines=$((lines + n))
  ntests=$(grep -Ec '#\[(tokio::)?test\]' "$file" || true)
  tests=$((tests + ntests))
done < <(find crates apps -type f -name '*.rs' -print | LC_ALL=C sort)
printf 'Independent file/awk audit:\n'
printf '  Rust files: %s\n' "$files"
printf '  Physical Rust lines: %s\n' "$lines"
printf '  Declared test functions: %s\n' "$tests"
printf '  Meets 100000+ LOC: '
if (( lines >= 100000 )); then printf 'yes\n'; else printf 'no\n'; fi
