# CloudScale — Rust autoscaling management platform (simulation-first)

CloudScale is an **original, AI-assisted Rust reference implementation** of a cloud autoscaling control plane. It accepts workload telemetry, evaluates CPU, memory and queue pressure, applies cost/bounds/cooldown safeguards, writes idempotent decisions, and exposes an authenticated REST API. A background controller uses expiring SQLite leases to coordinate **multiple processes on one host**.

> **Scope:** This release manages **simulation fleets only**. It does not invoke AWS, Azure, GCP or Kubernetes APIs. It is not a 100,000-line, mostly-human-written production product. See [AI disclosure](AI_DISCLOSURE.md), [eligibility](docs/ELIGIBILITY.md) and [verification](VERIFICATION.md) before making any submission claims.

## Features

- Deterministic Rust autoscaling engine with CPU/memory/queue signals and consecutive breach detection
- Bounded scale-out and conservative scale-in, hysteresis and cooldowns
- Hourly budget caps with explicit `budget_blocked` verdicts
- Basic linear forecast estimates for operational visibility (advisory only)
- Domain, store and service workspace crates, plus API and controller binaries
- SQLite persistence, atomic decision journal, compare-and-set versioning, idempotency by latest sample and policy revision
- Controller leases to avoid duplicate writes when multiple controller processes share one local SQLite database
- Authenticated REST endpoints for creating fleets, ingesting metrics, viewing previews and applying simulated changes
- Audit events, structured logs, validation and input limits
- Rust unit tests, SQLite integration test cases, deterministic invariants, CI, Docker Compose, issue/PR templates and documentation

## Architecture

```text
              metrics producer             operator / dashboard
                    |                                |
                    +---------------+----------------+
                                    |
                           REST API (Axum)
                           x-api-key auth
                                    |
                     CloudScale Engine (Rust)
                         /            \
                CloudScale Core    SQLite repository
                  policy rules        WAL + leases
                         \            /
                      Decision journal
                              |
                    Simulation provider only
                              ^
                              |
                    Background Controller
                      lease + periodic tick
```

Each evaluation is a **pure function of the fleet, policy, time, and observed metrics**. The database layer applies decisions transactionally. The simulation adapter sets observed replicas equal to desired replicas; real infrastructure reconciliation is a future milestone.

## Local development

**Requirements:** Rust 1.82+, Cargo, SQLite bundled by `sqlx`, `curl` and optionally Docker / Docker Compose. `jq` is used only by the demonstration script.

```bash
# From project root:
mkdir -p data
export DATABASE_URL='sqlite://data/cloudscale.db'
export CLOUDSCALE_API_KEY="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"

cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings
cargo test --workspace --all-targets

# Terminal 1:
cargo run -p cloudscale-api
# Terminal 2:
cargo run -p cloudscale-controller
# Terminal 3, with the same environment:
./examples/demo.sh
```

To run with containers:

```bash
cp .env.example .env
# Edit .env and replace the example key with a fresh, random secret.
docker compose up --build
```

The API binds to `127.0.0.1:8080` locally, and Docker Compose publishes only the loopback address. **Never expose it directly to the public Internet.** Authentication uses a single shared API key and is intended for developer environments, not enterprise IAM.

## Quick API example

```bash
# Authenticated simulation fleet creation:
curl -sS -X POST http://127.0.0.1:8080/v1/fleets \
  -H "x-api-key: $CLOUDSCALE_API_KEY" \
  -H 'Content-Type: application/json' \
  -d '{"name":"frontend-prod","region":"us-east-1", \
       "min_replicas":1,"max_replicas":12,"desired_replicas":2, \
       "hourly_cost_per_replica":0.25,"maximum_hourly_spend":2.0}'
```

Copy the returned fleet `id`, then:

```bash
export FLEET_ID='<uuid-from-response>'
for i in 1 2 3 4; do
  curl -sS -X POST "http://127.0.0.1:8080/v1/fleets/$FLEET_ID/metrics" \
    -H "x-api-key: $CLOUDSCALE_API_KEY" -H 'Content-Type: application/json' \
    -d '{"cpu_pct":95,"memory_pct":90,"queue_depth":400,"requests_per_second":100}'
done
curl -sS "http://127.0.0.1:8080/v1/fleets/$FLEET_ID/preview" \
  -H "x-api-key: $CLOUDSCALE_API_KEY"
curl -sS -X POST "http://127.0.0.1:8080/v1/fleets/$FLEET_ID/run" \
  -H "x-api-key: $CLOUDSCALE_API_KEY"
```

For machine-readable details, see [API reference](docs/API.md).

## Project structure

```text
crates/cloudscale-core       Domain models, validation, pure scaling algorithm and forecasts
crates/cloudscale-store      SQLite schema, journal, idempotency, leases and audit
crates/cloudscale-engine     Service layer: ingest, preview, apply, policy edits
apps/cloudscale-api          Axum JSON REST control plane
apps/cloudscale-controller   Tokio background scaling reconciler
migrations                   SQLite schema
examples                     End-to-end local demo
.github                      CI, issue and PR templates, Dependabot configuration
docs                         Architecture, API, operations, testing and roadmap
scripts                      Reproducible LOC / integrity audit scripts
```

## Verification and limitations

The repository includes an audit script and a second independent LOC counter. They validate file structure and metadata, but **they do not substitute for compiling Rust**. A proper release must pass `cargo fmt`, Clippy, all tests, Docker build and a runtime smoke test on a machine with Rust / Docker installed.

This initial code was generated predominantly with AI; no claim is made that the source is mostly human-written or that its GitHub PR history developed over months. Local commits represent actual commits made during this creation session; issue/PR templates are not real historical issues/PRs. Current real limitations include no live cloud adapters, no multi-host data store, no multi-tenant IAM, no rate limiting, no proven performance benchmark and no SLO commitments.

## Documentation

- [Architecture and decision flow](docs/ARCHITECTURE.md)
- [API reference](docs/API.md)
- [Local operations](docs/OPERATIONS.md)
- [Threat model](docs/THREAT_MODEL.md)
- [Test strategy](docs/TEST_PLAN.md)
- [Human development roadmap](docs/ROADMAP.md)
- [Ownership, licensing and eligibility](docs/ELIGIBILITY.md)
- [AI disclosure](AI_DISCLOSURE.md) / [Contributing](CONTRIBUTING.md) / [Security](SECURITY.md)

## License

[MIT](LICENSE). This applies to the repository's own code; third-party Rust dependencies retain their respective licenses. The contribution agreement is not a transfer of other developers' code rights. Nothing here is an assurance that an external organization's eligibility or originality conditions are met.
