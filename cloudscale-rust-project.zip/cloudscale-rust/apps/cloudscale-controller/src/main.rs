//! Optional background loop that evaluates each fleet and records decisions.
//! Leases and unique decision keys prevent repeated changes during local
//! multi-process operation. Real cloud provider writes are intentionally absent.

use chrono::Utc;
use cloudscale_engine::Engine;
use cloudscale_store::Store;
use std::env;
use std::time::Duration;
use tokio::time::{interval,MissedTickBehavior};
use tracing::{error,info,warn};
use uuid::Uuid;

async fn tick(engine:&Engine,owner:&str) -> Result<(usize,usize),Box<dyn std::error::Error>> {
    let now=Utc::now();
    let fleets=engine.store().list_fleets().await?;
    let mut evaluated=0usize;
    let mut changed=0usize;
    for fleet in fleets {
        if !engine.store().claim_lease(fleet.id,owner,now,45).await? {
            continue;
        }
        let result=engine.run_once(fleet.id,now).await;
        // Release independently of success; TTL recovers abandoned leases.
        if let Err(e)=engine.store().release_lease(fleet.id,owner).await {
            warn!(fleet_id=%fleet.id,error=%e,"failed to release controller lease");
        }
        match result {
            Ok(result) => {
                evaluated+=1;
                if result.recorded && result.evaluation.action.changes_capacity() {
                    changed+=1;
                    info!(fleet_id=%fleet.id, from=result.evaluation.current_replicas,
                        to=result.evaluation.proposed_replicas,
                        reason=%result.evaluation.reason,"simulation scaling decision applied");
                }
            },
            Err(e) => warn!(fleet_id=%fleet.id,error=%e,"fleet evaluation failed; next tick will retry"),
        }
    }
    Ok((evaluated,changed))
}

#[tokio::main]
async fn main() -> Result<(),Box<dyn std::error::Error>> {
    tracing_subscriber::fmt().with_env_filter(
        tracing_subscriber::EnvFilter::try_from_default_env()
            .unwrap_or_else(|_|tracing_subscriber::EnvFilter::new("info"))
    ).init();
    let database_url=env::var("DATABASE_URL").unwrap_or_else(|_|"sqlite://data/cloudscale.db".into());
    let every=env::var("CONTROLLER_TICK_SECONDS").ok()
        .and_then(|s|s.parse::<u64>().ok()).unwrap_or(15).clamp(2,3600);
    let once=env::args().any(|a|a=="--once");
    let owner=format!("cloudscale-controller-{}",Uuid::new_v4());
    let store=Store::open(&database_url).await?;
    let engine=Engine::new(store);
    info!(owner=%owner,interval_seconds=every,"controller started (simulation only)");
    if once {
        let (evaluated,changed)=tick(&engine,&owner).await?;
        info!(evaluated,changed,"one-shot evaluation completed");
        return Ok(());
    }
    let mut ticker=interval(Duration::from_secs(every));
    ticker.set_missed_tick_behavior(MissedTickBehavior::Skip);
    let mut cycle=0u32;
    loop {
        tokio::select! {
            _ = ticker.tick() => {
                match tick(&engine,&owner).await {
                    Ok((evaluated,changed)) => info!(evaluated,changed,"controller tick"),
                    Err(e) => error!(error=%e,"controller tick failed"),
                }
                cycle=cycle.wrapping_add(1);
                if cycle%100==0 {
                    match engine.store().prune_metrics(Utc::now(),30).await {
                        Ok(removed) => info!(removed,"expired metrics pruned"),
                        Err(e) => warn!(error=%e,"metrics prune failed"),
                    }
                }
            },
            ctrl = tokio::signal::ctrl_c() => {
                if let Err(e)=ctrl {warn!(error=%e,"ctrl-c handler failed");}
                info!("shutdown requested");
                break;
            }
        }
    }
    Ok(())
}
