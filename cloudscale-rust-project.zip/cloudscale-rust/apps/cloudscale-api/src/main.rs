//! CloudScale HTTP control plane.
//! This reference implementation deliberately supports only the simulation
//! provider. Every state-changing endpoint requires an API key.

use axum::extract::{Path, Query, Request, State};
use axum::http::StatusCode;
use axum::middleware::{self, Next};
use axum::response::{IntoResponse, Response};
use axum::routing::{get, post};
use axum::{Json, Router};
use chrono::Utc;
use cloudscale_core::{Fleet, FleetSpec, Policy};
use cloudscale_engine::{Engine, EngineError, MetricInput, RunOutcome};
use cloudscale_store::{AuditEvent, DecisionRecord, Store, StoreError};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::env;
use std::sync::Arc;
use subtle::ConstantTimeEq;
use tower_http::trace::TraceLayer;
use tracing::{error, info, warn};
use uuid::Uuid;

#[derive(Clone)]
struct AppState {
    engine: Arc<Engine>,
    api_key: Arc<String>,
}

#[derive(Debug)]
struct ApiError {
    status: StatusCode,
    message: String,
}

impl ApiError {
    fn invalid(message: impl Into<String>) -> Self {
        Self { status: StatusCode::BAD_REQUEST, message: message.into() }
    }
    fn internal() -> Self {
        Self { status: StatusCode::INTERNAL_SERVER_ERROR,
            message: "internal service error; consult server logs".into() }
    }
}

impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        (self.status, Json(json!({"error":self.message}))).into_response()
    }
}

impl From<StoreError> for ApiError {
    fn from(error: StoreError) -> Self {
        match error {
            StoreError::NotFound(message) => Self { status: StatusCode::NOT_FOUND, message },
            StoreError::Conflict => Self { status: StatusCode::CONFLICT, message: "concurrent modification; retry with current state".into() },
            StoreError::Invalid(message) => Self::invalid(message),
            StoreError::Database(ref db_error) if is_constraint_error(db_error) => Self {
                status: StatusCode::CONFLICT, message: "resource or metric already exists".into(),
            },
            other => { error!(error=%other,"storage failure"); Self::internal() },
        }
    }
}

fn is_constraint_error(error: &sqlx::Error) -> bool {
    if let sqlx::Error::Database(db) = error { db.is_unique_violation() || db.is_foreign_key_violation() }
    else { false }
}

impl From<EngineError> for ApiError {
    fn from(error: EngineError) -> Self {
        match error {
            EngineError::Domain(e) => Self::invalid(e.to_string()),
            EngineError::Storage(e) => Self::from(e),
        }
    }
}

fn parse_id(raw: &str) -> Result<Uuid,ApiError> {
    Uuid::parse_str(raw).map_err(|_| ApiError::invalid("fleet ID must be a UUID"))
}

/// Reject missing, mismatched or underspecified API keys. Health checks are
/// installed on a different router branch and intentionally remain public.
async fn require_api_key(State(state): State<AppState>, request: Request, next: Next) -> Result<Response,StatusCode> {
    let provided = request.headers().get("x-api-key").and_then(|v|v.to_str().ok()).unwrap_or("");
    let authorized = bool::from(provided.as_bytes().ct_eq(state.api_key.as_bytes()));
    if !authorized {return Err(StatusCode::UNAUTHORIZED);}
    Ok(next.run(request).await)
}

async fn health() -> Json<Value> {
    Json(json!({"status":"ok","provider":"simulation","write_target":"local SQLite"}))
}

async fn ready(State(state): State<AppState>) -> Response {
    match state.engine.store().ping().await {
        Ok(()) => (StatusCode::OK,Json(json!({"ready":true}))).into_response(),
        Err(e) => { warn!(error=%e,"readiness check failed");
            (StatusCode::SERVICE_UNAVAILABLE,Json(json!({"ready":false}))).into_response() },
    }
}

async fn create_fleet(State(state): State<AppState>,Json(spec): Json<FleetSpec>) -> Result<(StatusCode,Json<Fleet>),ApiError> {
    let fleet=state.engine.create_fleet(spec,Utc::now()).await?;
    Ok((StatusCode::CREATED,Json(fleet)))
}

async fn list_fleets(State(state): State<AppState>) -> Result<Json<Vec<Fleet>>,ApiError> {
    Ok(Json(state.engine.store().list_fleets().await?))
}

async fn get_fleet(State(state): State<AppState>,Path(raw): Path<String>) -> Result<Json<Fleet>,ApiError> {
    Ok(Json(state.engine.store().get_fleet(parse_id(&raw)?).await?))
}

async fn get_policy(State(state): State<AppState>,Path(raw):Path<String>) -> Result<Json<Policy>,ApiError> {
    Ok(Json(state.engine.store().get_policy(parse_id(&raw)?).await?))
}

async fn replace_policy(State(state): State<AppState>,Path(raw):Path<String>,Json(policy):Json<Policy>) -> Result<Json<Policy>,ApiError> {
    let id=parse_id(&raw)?;
    let updated=state.engine.replace_policy(id,policy,"api-client",Utc::now()).await?;
    Ok(Json(updated))
}

async fn ingest_metrics(State(state): State<AppState>,Path(raw):Path<String>,Json(input):Json<MetricInput>) -> Result<(StatusCode,Json<Value>),ApiError> {
    let sample=state.engine.record_metric(parse_id(&raw)?,input,Utc::now()).await?;
    Ok((StatusCode::CREATED,Json(json!({"id":sample.id,"accepted":true,"sampled_at":sample.sampled_at}))))
}

#[derive(Debug,Deserialize)]
struct Pagination { limit: Option<i64> }

async fn list_metrics(State(state):State<AppState>,Path(raw):Path<String>,Query(page):Query<Pagination>) -> Result<Json<Vec<cloudscale_core::MetricSample>>,ApiError> {
    let id=parse_id(&raw)?;
    state.engine.store().get_fleet(id).await?;
    let samples=state.engine.store().recent_metrics(id,Utc::now()-chrono::Duration::days(7),page.limit.unwrap_or(200)).await?;
    Ok(Json(samples))
}

async fn preview(State(state):State<AppState>,Path(raw):Path<String>) -> Result<Json<cloudscale_core::Evaluation>,ApiError> {
    Ok(Json(state.engine.preview(parse_id(&raw)?,Utc::now()).await?))
}

async fn run_once(State(state):State<AppState>,Path(raw):Path<String>) -> Result<Json<RunOutcome>,ApiError> {
    let id=parse_id(&raw)?;
    // The optimistic write and unique decision key protect against API and
    // controller concurrent requests; successful duplicate returns recorded=false.
    Ok(Json(state.engine.run_once(id,Utc::now()).await?))
}

async fn list_decisions(State(state):State<AppState>,Path(raw):Path<String>,Query(page):Query<Pagination>) -> Result<Json<Vec<DecisionRecord>>,ApiError> {
    let id=parse_id(&raw)?;
    state.engine.store().get_fleet(id).await?;
    Ok(Json(state.engine.store().list_decisions(id,page.limit.unwrap_or(100)).await?))
}

async fn list_audit(State(state):State<AppState>,Path(raw):Path<String>,Query(page):Query<Pagination>) -> Result<Json<Vec<AuditEvent>>,ApiError> {
    let id=parse_id(&raw)?;
    state.engine.store().get_fleet(id).await?;
    Ok(Json(state.engine.store().list_audit(id,page.limit.unwrap_or(100)).await?))
}

#[derive(Debug,Serialize)]
struct Stats {
    total_fleets: usize,
    enabled_fleets: usize,
    desired_replicas: u64,
    hourly_spend_estimate: f64,
    simulation_only: bool,
}

async fn stats(State(state):State<AppState>) -> Result<Json<Stats>,ApiError> {
    let fleets=state.engine.store().list_fleets().await?;
    Ok(Json(Stats {total_fleets:fleets.len(),
        enabled_fleets:fleets.iter().filter(|f|f.enabled).count(),
        desired_replicas:fleets.iter().map(|f|f.desired_replicas as u64).sum(),
        hourly_spend_estimate:fleets.iter().map(|f|f.hourly_spend(f.desired_replicas)).sum(),
        simulation_only:true }))
}

fn app(state: AppState) -> Router {
    let protected = Router::new()
        .route("/v1/fleets",post(create_fleet).get(list_fleets))
        .route("/v1/fleets/:id",get(get_fleet))
        .route("/v1/fleets/:id/policy",get(get_policy).put(replace_policy))
        .route("/v1/fleets/:id/metrics",get(list_metrics).post(ingest_metrics))
        .route("/v1/fleets/:id/preview",get(preview))
        .route("/v1/fleets/:id/run",post(run_once))
        .route("/v1/fleets/:id/decisions",get(list_decisions))
        .route("/v1/fleets/:id/audit",get(list_audit))
        .route("/v1/stats",get(stats))
        .route_layer(middleware::from_fn_with_state(state.clone(),require_api_key));
    Router::new().route("/healthz",get(health)).route("/readyz",get(ready))
        .merge(protected).with_state(state).layer(TraceLayer::new_for_http())
}

#[tokio::main]
async fn main() -> Result<(),Box<dyn std::error::Error>> {
    tracing_subscriber::fmt().with_env_filter(
        tracing_subscriber::EnvFilter::try_from_default_env()
            .unwrap_or_else(|_|tracing_subscriber::EnvFilter::new("info"))
    ).init();
    let api_key=env::var("CLOUDSCALE_API_KEY")
        .map_err(|_|"CLOUDSCALE_API_KEY must be set (at least 24 characters)")?;
    if api_key.len()<24 {return Err("CLOUDSCALE_API_KEY must be at least 24 characters".into());}
    let database_url=env::var("DATABASE_URL").unwrap_or_else(|_|"sqlite://data/cloudscale.db".into());
    let bind_address=env::var("BIND_ADDRESS").unwrap_or_else(|_|"127.0.0.1:8080".into());
    let store=Store::open(&database_url).await?;
    let state=AppState {engine:Arc::new(Engine::new(store)),api_key:Arc::new(api_key)};
    let listener=tokio::net::TcpListener::bind(&bind_address).await?;
    info!(address=%bind_address,"CloudScale API ready (simulation mode)");
    axum::serve(listener,app(state))
        .with_graceful_shutdown(async {
            if tokio::signal::ctrl_c().await.is_err() {error!("failed to register ctrl-c signal");}
        }).await?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn uuid_parsing_rejects_garbage() {assert!(parse_id("wrong").is_err());}
    #[test] fn uuid_parsing_accepts_uuid() {let u=Uuid::new_v4();assert_eq!(parse_id(&u.to_string()).unwrap(),u);}
    #[test] fn sqlite_constraint_conflict_is_not_internal() {
        let err=StoreError::Conflict;
        assert_eq!(ApiError::from(err).status,StatusCode::CONFLICT);
    }
}
