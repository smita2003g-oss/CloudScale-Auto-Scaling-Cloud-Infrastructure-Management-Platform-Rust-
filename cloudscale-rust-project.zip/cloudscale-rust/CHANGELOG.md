# Changelog

## 0.1.0 (initial generated reference implementation)

- Added Rust workspace core models, policy validation, autoscaling evaluator and advisory forecasting.
- Added SQLite fleet/policy/metrics storage, controller lease protocol and idempotent decision journal.
- Added Axum REST control plane and Tokio background controller (simulation only).
- Added deterministic policy unit tests, SQLite integration test cases, invariant loops and CI configuration.
- Added Docker Compose, basic REST demo, operational docs, security limitations, authorship disclosure and audit scripts.

**Status:** Source generated; compilation and runtime tests have not been executed in this environment.
