PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS fleets (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL UNIQUE,
    state_json TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 0 CHECK (version >= 0),
    created_at_ms INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS policies (
    fleet_id TEXT PRIMARY KEY NOT NULL,
    policy_json TEXT NOT NULL,
    revision INTEGER NOT NULL CHECK (revision > 0),
    FOREIGN KEY(fleet_id) REFERENCES fleets(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS metric_samples (
    id TEXT PRIMARY KEY NOT NULL,
    fleet_id TEXT NOT NULL,
    sampled_at_ms INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    FOREIGN KEY(fleet_id) REFERENCES fleets(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_metric_samples_fleet_time
    ON metric_samples (fleet_id, sampled_at_ms DESC);

CREATE TABLE IF NOT EXISTS decisions (
    id TEXT PRIMARY KEY NOT NULL,
    fleet_id TEXT NOT NULL,
    decision_key TEXT NOT NULL UNIQUE,
    decision_json TEXT NOT NULL,
    changed INTEGER NOT NULL CHECK (changed IN (0,1)),
    created_at_ms INTEGER NOT NULL,
    FOREIGN KEY(fleet_id) REFERENCES fleets(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_decisions_fleet_time
    ON decisions (fleet_id, created_at_ms DESC);

CREATE TABLE IF NOT EXISTS controller_leases (
    fleet_id TEXT PRIMARY KEY NOT NULL,
    owner_id TEXT NOT NULL,
    expires_at_ms INTEGER NOT NULL,
    FOREIGN KEY(fleet_id) REFERENCES fleets(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS audit_events (
    id TEXT PRIMARY KEY NOT NULL,
    fleet_id TEXT NOT NULL,
    category TEXT NOT NULL,
    actor TEXT NOT NULL,
    detail TEXT NOT NULL,
    recorded_at_ms INTEGER NOT NULL,
    FOREIGN KEY(fleet_id) REFERENCES fleets(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_audit_fleet_time
    ON audit_events (fleet_id, recorded_at_ms DESC);
