# Security policy

This repository is **an experimental simulation reference**, not a hosted production cloud management service. It controls no real cloud accounts. It has not yet received an independent security audit, fuzzing campaign or verified container runtime test.

If you discover a vulnerability, avoid opening public issues containing exploitable secrets or personal data. Privately contact the actual repository maintainer after a repository has been published and contact details established. **No real maintainer email or bug-bounty program has been invented for this artifact.**

Current security limitations: a shared API key rather than IAM, no HTTPS termination, no rate limiting, local SQLite, no multi-tenant RBAC, no provider IAM, and no automated vulnerability scan evidence. The Docker configuration publishes to loopback only. Do not expose the HTTP API over the Internet without independent security hardening.

The recommended pre-release security checklist is in [threat model](docs/THREAT_MODEL.md) and [release checklist](docs/RELEASE_CHECKLIST.md).
