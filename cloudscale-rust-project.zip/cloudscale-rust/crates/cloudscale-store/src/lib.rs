//! SQLite-based repository, idempotent decision journal and leader leases.
//!
//! SQLite is a good local reference backend; multiple controllers can share
//! the same SQLite database only on a suitable local filesystem. It is NOT
//! supported for multi-host access over network filesystems. For truly
//! distributed multi-host operation, replace this repository with Postgres.

use chrono::{DateTime, Utc};
use cloudscale_core::{Evaluation, Fleet, MetricSample, Policy};
use serde::{Deserialize, Serialize};
use sqlx::sqlite::{SqliteConnectOptions, SqlitePoolOptions};
use sqlx::{Row, SqlitePool};
use std::str::FromStr;
use std::time::Duration;
use thiserror::Error;
use uuid::Uuid;

#[derive(Debug, Error)]
pub enum StoreError {
    #[error("record not found: {0}")]
    NotFound(String),
    #[error("optimistic concurrency conflict or stale policy")]
    Conflict,
    #[error("invalid input: {0}")]
    Invalid(String),
    #[error(transparent)]
    Database(#[from] sqlx::Error),
    #[error(transparent)]
    Serialization(#[from] serde_json::Error),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DecisionRecord {
    pub id: Uuid,
    pub fleet_id: Uuid,
    pub evaluation: Evaluation,
    pub applied: bool,
    pub key: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditEvent {
    pub id: Uuid,
    pub fleet_id: Uuid,
    pub category: String,
    pub actor: String,
    pub detail: String,
    pub recorded_at: DateTime<Utc>,
}

#[derive(Clone)]
pub struct Store {
    pool: SqlitePool,
}

impl Store {
    pub async fn open(database_url: &str) -> Result<Self, StoreError> {
        let memory = database_url.contains(":memory:");
        let options = SqliteConnectOptions::from_str(database_url)?
            .create_if_missing(true)
            .foreign_keys(true)
            .busy_timeout(Duration::from_secs(5));
        let pool = SqlitePoolOptions::new()
            .max_connections(if memory { 1 } else { 5 })
            .connect_with(options).await?;
        let store = Self { pool };
        store.migrate().await?;
        Ok(store)
    }

    pub async fn migrate(&self) -> Result<(), StoreError> {
        sqlx::raw_sql(include_str!("../../../migrations/0001_init.sql"))
            .execute(&self.pool).await?;
        Ok(())
    }

    pub async fn ping(&self) -> Result<(), StoreError> {
        let _: i64 = sqlx::query_scalar("SELECT 1").fetch_one(&self.pool).await?;
        Ok(())
    }

    pub async fn create_fleet(&self, fleet: &Fleet, policy: &Policy) -> Result<(), StoreError> {
        if policy.fleet_id != fleet.id { return Err(StoreError::Invalid("policy fleet mismatch".into())); }
        let mut tx = self.pool.begin().await?;
        sqlx::query("INSERT INTO fleets (id,name,state_json,version,created_at_ms) VALUES (?,?,?,?,?)")
            .bind(fleet.id.to_string()).bind(&fleet.name)
            .bind(serde_json::to_string(fleet)?).bind(fleet.version as i64)
            .bind(fleet.created_at.timestamp_millis())
            .execute(&mut *tx).await?;
        sqlx::query("INSERT INTO policies (fleet_id,policy_json,revision) VALUES (?,?,?)")
            .bind(fleet.id.to_string()).bind(serde_json::to_string(policy)?)
            .bind(policy.revision as i64).execute(&mut *tx).await?;
        insert_audit(&mut tx, fleet.id, "fleet.created", "api", "simulation fleet created", fleet.created_at).await?;
        tx.commit().await?;
        Ok(())
    }

    pub async fn get_fleet(&self, id: Uuid) -> Result<Fleet, StoreError> {
        let row = sqlx::query("SELECT state_json FROM fleets WHERE id = ?")
            .bind(id.to_string()).fetch_optional(&self.pool).await?
            .ok_or_else(|| StoreError::NotFound(format!("fleet {id}")))?;
        let fleet = serde_json::from_str(row.try_get("state_json")?)?;
        Ok(fleet)
    }

    pub async fn list_fleets(&self) -> Result<Vec<Fleet>, StoreError> {
        let rows = sqlx::query("SELECT state_json FROM fleets ORDER BY name ASC")
            .fetch_all(&self.pool).await?;
        let mut fleets = Vec::with_capacity(rows.len());
        for row in rows {
            fleets.push(serde_json::from_str(row.try_get("state_json")?)?);
        }
        Ok(fleets)
    }

    pub async fn get_policy(&self, id: Uuid) -> Result<Policy, StoreError> {
        let row = sqlx::query("SELECT policy_json FROM policies WHERE fleet_id = ?")
            .bind(id.to_string()).fetch_optional(&self.pool).await?
            .ok_or_else(|| StoreError::NotFound(format!("policy for fleet {id}")))?;
        Ok(serde_json::from_str(row.try_get("policy_json")?)?)
    }

    /// Atomic optimistic revision update prevents accidental policy overwrites.
    pub async fn replace_policy(&self, policy: &Policy, actor: &str, now: DateTime<Utc>) -> Result<Policy, StoreError> {
        let old = self.get_policy(policy.fleet_id).await?;
        // The client's revision is an optimistic precondition, not a hint.
        // Never overwrite a policy that changed since the client read it.
        if policy.revision != old.revision { return Err(StoreError::Conflict); }
        let mut new_policy = policy.clone();
        new_policy.revision = old.revision.checked_add(1).ok_or(StoreError::Conflict)?;
        let mut tx = self.pool.begin().await?;
        let changed = sqlx::query("UPDATE policies SET policy_json=?,revision=? WHERE fleet_id=? AND revision=?")
            .bind(serde_json::to_string(&new_policy)?)
            .bind(new_policy.revision as i64).bind(new_policy.fleet_id.to_string())
            .bind(old.revision as i64).execute(&mut *tx).await?.rows_affected();
        if changed != 1 { return Err(StoreError::Conflict); }
        insert_audit(&mut tx, new_policy.fleet_id, "policy.updated", actor,
            &format!("revision {} -> {}", old.revision, new_policy.revision), now).await?;
        tx.commit().await?;
        Ok(new_policy)
    }

    pub async fn insert_metric(&self, sample: &MetricSample) -> Result<(), StoreError> {
        sqlx::query("INSERT INTO metric_samples (id,fleet_id,sampled_at_ms,payload_json) VALUES (?,?,?,?)")
            .bind(sample.id.to_string()).bind(sample.fleet_id.to_string())
            .bind(sample.sampled_at.timestamp_millis())
            .bind(serde_json::to_string(sample)?)
            .execute(&self.pool).await?;
        Ok(())
    }

    pub async fn recent_metrics(&self, id: Uuid, cutoff: DateTime<Utc>, limit: i64) -> Result<Vec<MetricSample>, StoreError> {
        let rows = sqlx::query("SELECT payload_json FROM metric_samples WHERE fleet_id=? AND sampled_at_ms>=? ORDER BY sampled_at_ms DESC, id DESC LIMIT ?")
            .bind(id.to_string()).bind(cutoff.timestamp_millis())
            .bind(limit.clamp(1, 2000)).fetch_all(&self.pool).await?;
        let mut samples = Vec::with_capacity(rows.len());
        for row in rows { samples.push(serde_json::from_str(row.try_get("payload_json")?)?); }
        samples.reverse();
        Ok(samples)
    }

    /// Each (fleet, policy revision, newest metric) is evaluated at most once.
    /// An optimistic fleet version check makes updating replicas atomic with
    /// journaling. Retrying after a crash returns the previous decision.
    pub async fn commit_decision(&self, current: &Fleet, evaluation: &Evaluation) -> Result<bool, StoreError> {
        if current.id != evaluation.fleet_id { return Err(StoreError::Invalid("decision fleet mismatch".into())); }
        if evaluation.current_replicas != current.desired_replicas {
            return Err(StoreError::Conflict);
        }
        let key = decision_key(evaluation);
        let changed = evaluation.action.changes_capacity()
            && evaluation.proposed_replicas != current.desired_replicas;
        let record = DecisionRecord {
            id: Uuid::new_v4(), fleet_id: current.id,
            evaluation: evaluation.clone(), applied: changed, key: key.clone(),
        };
        let mut tx = self.pool.begin().await?;
        let actual_revision: Option<i64> = sqlx::query_scalar("SELECT revision FROM policies WHERE fleet_id=?")
            .bind(current.id.to_string()).fetch_optional(&mut *tx).await?;
        if actual_revision != Some(evaluation.policy_revision as i64) {
            return Err(StoreError::Conflict);
        }
        let inserted = sqlx::query("INSERT INTO decisions (id,fleet_id,decision_key,decision_json,changed,created_at_ms) VALUES (?,?,?,?,?,?) ON CONFLICT(decision_key) DO NOTHING")
            .bind(record.id.to_string()).bind(record.fleet_id.to_string())
            .bind(&record.key).bind(serde_json::to_string(&record)?)
            .bind(if changed {1} else {0}).bind(evaluation.evaluated_at.timestamp_millis())
            .execute(&mut *tx).await?.rows_affected();
        if inserted == 0 {
            tx.rollback().await?;
            return Ok(false);
        }
        if changed {
            if evaluation.proposed_replicas < current.min_replicas || evaluation.proposed_replicas > current.max_replicas {
                return Err(StoreError::Invalid("decision exceeds hard capacity bounds".into()));
            }
            if current.maximum_hourly_spend.is_some_and(|budget| current.hourly_spend(evaluation.proposed_replicas) > budget + 1e-9) {
                return Err(StoreError::Invalid("decision exceeds hard hourly budget".into()));
            }
            let mut new_state = current.clone();
            new_state.version = new_state.version.checked_add(1).ok_or(StoreError::Conflict)?;
            new_state.desired_replicas = evaluation.proposed_replicas;
            // The current provider is explicitly simulation-only.
            new_state.observed_replicas = evaluation.proposed_replicas;
            new_state.last_scaled_at = Some(evaluation.evaluated_at);
            let rows = sqlx::query("UPDATE fleets SET state_json=?,version=? WHERE id=? AND version=?")
                .bind(serde_json::to_string(&new_state)?)
                .bind(new_state.version as i64).bind(current.id.to_string())
                .bind(current.version as i64).execute(&mut *tx).await?.rows_affected();
            if rows != 1 { return Err(StoreError::Conflict); }
            insert_audit(&mut tx, current.id, "capacity.changed", "controller",
                &format!("{} -> {} replicas; {}",current.desired_replicas,
                    new_state.desired_replicas,evaluation.reason),evaluation.evaluated_at).await?;
        }
        tx.commit().await?;
        Ok(true)
    }

    pub async fn list_decisions(&self, id: Uuid, limit: i64) -> Result<Vec<DecisionRecord>, StoreError> {
        let rows=sqlx::query("SELECT decision_json FROM decisions WHERE fleet_id=? ORDER BY created_at_ms DESC,id DESC LIMIT ?")
            .bind(id.to_string()).bind(limit.clamp(1, 250)).fetch_all(&self.pool).await?;
        let mut output=Vec::with_capacity(rows.len());
        for row in rows { output.push(serde_json::from_str(row.try_get("decision_json")?)?); }
        Ok(output)
    }

    pub async fn list_audit(&self, id: Uuid, limit: i64) -> Result<Vec<AuditEvent>, StoreError> {
        let rows=sqlx::query("SELECT event_json FROM (SELECT json_object('id',id,'fleet_id',fleet_id,'category',category,'actor',actor,'detail',detail,'recorded_at',strftime('%Y-%m-%dT%H:%M:%fZ', recorded_at_ms / 1000.0, 'unixepoch')) AS event_json,recorded_at_ms FROM audit_events WHERE fleet_id=?) ORDER BY recorded_at_ms DESC LIMIT ?")
            .bind(id.to_string()).bind(limit.clamp(1,250)).fetch_all(&self.pool).await?;
        let mut events=Vec::with_capacity(rows.len());
        for row in rows { events.push(serde_json::from_str(row.try_get("event_json")?)?); }
        Ok(events)
    }

    /// Compare-and-set lease; suitable for controllers sharing one local SQLite file.
    pub async fn claim_lease(&self, id: Uuid, owner: &str, now: DateTime<Utc>, ttl_seconds: i64) -> Result<bool, StoreError> {
        if owner.is_empty() || owner.len() > 120 || !(1..=3600).contains(&ttl_seconds) {
            return Err(StoreError::Invalid("invalid lease owner or duration".into()));
        }
        let changed = sqlx::query("INSERT INTO controller_leases (fleet_id,owner_id,expires_at_ms) VALUES (?,?,?) ON CONFLICT(fleet_id) DO UPDATE SET owner_id=excluded.owner_id,expires_at_ms=excluded.expires_at_ms WHERE controller_leases.expires_at_ms<? OR controller_leases.owner_id=excluded.owner_id")
            .bind(id.to_string()).bind(owner)
            .bind((now+chrono::Duration::seconds(ttl_seconds)).timestamp_millis())
            .bind(now.timestamp_millis()).execute(&self.pool).await?.rows_affected();
        Ok(changed==1)
    }

    pub async fn release_lease(&self,id:Uuid,owner:&str) -> Result<(),StoreError> {
        sqlx::query("DELETE FROM controller_leases WHERE fleet_id=? AND owner_id=?")
            .bind(id.to_string()).bind(owner).execute(&self.pool).await?;
        Ok(())
    }

    pub async fn prune_metrics(&self, now: DateTime<Utc>, keep_days: i64) -> Result<u64, StoreError> {
        if !(1..=365).contains(&keep_days) {return Err(StoreError::Invalid("keep_days must be 1..=365".into()));}
        let removed=sqlx::query("DELETE FROM metric_samples WHERE sampled_at_ms<?")
            .bind((now-chrono::Duration::days(keep_days)).timestamp_millis())
            .execute(&self.pool).await?.rows_affected();
        Ok(removed)
    }
}

pub fn decision_key(evaluation: &Evaluation) -> String {
    format!("{}:{}:{}",evaluation.fleet_id,evaluation.policy_revision,
        evaluation.newest_sample_id.map(|id|id.to_string()).unwrap_or_else(||"no-metrics".into()))
}

async fn insert_audit(tx: &mut sqlx::Transaction<'_, sqlx::Sqlite>,fleet_id:Uuid,category:&str,actor:&str,detail:&str,now:DateTime<Utc>) -> Result<(), StoreError> {
    sqlx::query("INSERT INTO audit_events (id,fleet_id,category,actor,detail,recorded_at_ms) VALUES (?,?,?,?,?,?)")
        .bind(Uuid::new_v4().to_string()).bind(fleet_id.to_string())
        .bind(category).bind(actor).bind(detail).bind(now.timestamp_millis())
        .execute(&mut **tx).await?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use cloudscale_core::{evaluate, FleetSpec, ScaleAction};

    async fn fixture() -> (Store, Fleet, Policy) {
        let db=Store::open("sqlite::memory:").await.unwrap();
        let fleet=Fleet::new(FleetSpec {name:"test-prod".into(),region:"us-west-2".into(),
            min_replicas:1,max_replicas:8,desired_replicas:2,
            hourly_cost_per_replica:0.50,maximum_hourly_spend:Some(4.0)},Utc::now()).unwrap();
        let policy=Policy::default_for(fleet.id);
        db.create_fleet(&fleet,&policy).await.unwrap();
        (db,fleet,policy)
    }
    fn test_metrics(fleet:&Fleet,now:DateTime<Utc>) -> Vec<MetricSample> {
        (0..4).map(|n|MetricSample {id:Uuid::new_v4(),fleet_id:fleet.id,
            sampled_at:now-chrono::Duration::seconds((4-n)*10),
            cpu_pct:95.0,memory_pct:91.0,queue_depth:160,requests_per_second:200.0}).collect()
    }

    #[tokio::test] async fn schema_and_health_check() { let (s,_,_)=fixture().await; s.ping().await.unwrap(); }
    #[tokio::test] async fn create_and_load_fleet() { let (s,f,_)=fixture().await; let loaded=s.get_fleet(f.id).await.unwrap(); assert_eq!(loaded.name,f.name); }
    #[tokio::test] async fn list_fleets_contains_created() { let (s,_,_)=fixture().await; assert_eq!(s.list_fleets().await.unwrap().len(),1); }
    #[tokio::test] async fn nonexistent_fleet_returns_not_found() { let (s,_,_)=fixture().await; assert!(matches!(s.get_fleet(Uuid::new_v4()).await,Err(StoreError::NotFound(_)))); }
    #[tokio::test] async fn policy_revision_increments() { let (s,f,_)=fixture().await; let p=s.get_policy(f.id).await.unwrap(); let newer=s.replace_policy(&p,"test",Utc::now()).await.unwrap(); assert_eq!(newer.revision,p.revision+1); }
    #[tokio::test] async fn metrics_roundtrip() { let (s,f,_)=fixture().await; let m=test_metrics(&f,Utc::now()); for sample in &m {s.insert_metric(sample).await.unwrap();} let got=s.recent_metrics(f.id,Utc::now()-chrono::Duration::minutes(5),200).await.unwrap(); assert_eq!(got.len(),4); }
    #[tokio::test] async fn duplicate_metric_is_rejected() { let (s,f,_)=fixture().await; let m=test_metrics(&f,Utc::now()); s.insert_metric(&m[0]).await.unwrap(); assert!(s.insert_metric(&m[0]).await.is_err()); }
    #[tokio::test] async fn distinct_controller_lease_is_exclusive() { let (s,f,_)=fixture().await; let n=Utc::now(); assert!(s.claim_lease(f.id,"owner-a",n,30).await.unwrap()); assert!(!s.claim_lease(f.id,"owner-b",n,30).await.unwrap()); }
    #[tokio::test] async fn expired_lease_can_be_reclaimed() { let (s,f,_)=fixture().await; let n=Utc::now(); assert!(s.claim_lease(f.id,"owner-a",n,10).await.unwrap()); assert!(s.claim_lease(f.id,"owner-b",n+chrono::Duration::seconds(11),10).await.unwrap()); }
    #[tokio::test] async fn lease_release_allows_new_owner() { let (s,f,_)=fixture().await; let n=Utc::now(); s.claim_lease(f.id,"a",n,10).await.unwrap(); s.release_lease(f.id,"a").await.unwrap(); assert!(s.claim_lease(f.id,"b",n,10).await.unwrap()); }
    #[tokio::test] async fn same_metric_cannot_apply_twice() { let (s,f,p)=fixture().await; let n=Utc::now(); let m=test_metrics(&f,n); let d=evaluate(&f,&p,&m,n); assert_eq!(d.action,ScaleAction::ScaleOut); assert!(s.commit_decision(&f,&d).await.unwrap()); assert!(!s.commit_decision(&f,&d).await.unwrap()); assert_eq!(s.get_fleet(f.id).await.unwrap().version,1); }
    #[tokio::test] async fn old_version_cannot_commit_another_action() { let (s,f,p)=fixture().await; let n=Utc::now(); let m=test_metrics(&f,n); let d=evaluate(&f,&p,&m,n); s.commit_decision(&f,&d).await.unwrap(); let mut alt=d.clone(); alt.newest_sample_id=Some(Uuid::new_v4()); assert!(matches!(s.commit_decision(&f,&alt).await,Err(StoreError::Conflict))); }
    #[tokio::test] async fn audit_records_created_and_scale() { let (s,f,p)=fixture().await; let n=Utc::now(); let d=evaluate(&f,&p,&test_metrics(&f,n),n); s.commit_decision(&f,&d).await.unwrap(); assert_eq!(s.list_audit(f.id,30).await.unwrap().len(),2); }
    #[tokio::test] async fn decision_roundtrip() { let (s,f,p)=fixture().await; let n=Utc::now(); let d=evaluate(&f,&p,&test_metrics(&f,n),n); s.commit_decision(&f,&d).await.unwrap(); let got=s.list_decisions(f.id,10).await.unwrap(); assert_eq!(got.len(),1); assert!(got[0].applied); }
    #[tokio::test] async fn policy_staleness_blocks_decision() { let (s,f,p)=fixture().await; let n=Utc::now(); s.replace_policy(&p,"test",n).await.unwrap(); let d=evaluate(&f,&p,&test_metrics(&f,n),n); assert!(matches!(s.commit_decision(&f,&d).await,Err(StoreError::Conflict))); }
    #[tokio::test] async fn stale_policy_write_is_rejected() { let (s,_,p)=fixture().await; s.replace_policy(&p,"test",Utc::now()).await.unwrap(); assert!(matches!(s.replace_policy(&p,"stale-client",Utc::now()).await,Err(StoreError::Conflict))); }
    #[tokio::test] async fn prune_with_invalid_keep_days_rejected() { let (s,_,_)=fixture().await; assert!(matches!(s.prune_metrics(Utc::now(),0).await,Err(StoreError::Invalid(_)))); }
}
