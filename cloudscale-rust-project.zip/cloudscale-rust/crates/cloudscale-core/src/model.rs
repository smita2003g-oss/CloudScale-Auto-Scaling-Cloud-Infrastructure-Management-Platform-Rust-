use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use thiserror::Error;
use uuid::Uuid;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Provider {
    /// Simulates desired and observed changes locally; never talks to a cloud account.
    Simulation,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FleetSpec {
    pub name: String,
    pub region: String,
    pub min_replicas: u32,
    pub max_replicas: u32,
    pub desired_replicas: u32,
    pub hourly_cost_per_replica: f64,
    pub maximum_hourly_spend: Option<f64>,
}

impl FleetSpec {
    pub fn validate(&self) -> Result<(), DomainError> {
        let name = self.name.trim();
        if name.len() < 3 || name.len() > 80 || !valid_identifier(name) {
            return Err(DomainError::Invalid("name must be 3-80 ASCII letters, digits, hyphens or underscores".into()));
        }
        if self.region.len() > 48 || self.region.is_empty() || !valid_identifier(&self.region) {
            return Err(DomainError::Invalid("invalid region".into()));
        }
        if self.min_replicas == 0 || self.max_replicas > 100_000 || self.min_replicas > self.max_replicas {
            return Err(DomainError::Invalid("replica bounds must satisfy 1 <= min <= max <= 100000".into()));
        }
        if !(self.min_replicas..=self.max_replicas).contains(&self.desired_replicas) {
            return Err(DomainError::Invalid("desired_replicas must be between min and max".into()));
        }
        if !self.hourly_cost_per_replica.is_finite() || self.hourly_cost_per_replica <= 0.0 || self.hourly_cost_per_replica > 10_000_000.0 {
            return Err(DomainError::Invalid("hourly_cost_per_replica must be finite and positive".into()));
        }
        if let Some(limit) = self.maximum_hourly_spend {
            if !limit.is_finite() || limit <= 0.0 {
                return Err(DomainError::Invalid("maximum_hourly_spend must be finite and positive".into()));
            }
            if self.desired_replicas as f64 * self.hourly_cost_per_replica > limit + 1e-9 {
                return Err(DomainError::Invalid("starting desired replicas exceed hourly budget".into()));
            }
        }
        Ok(())
    }
}

fn valid_identifier(input: &str) -> bool {
    input.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Fleet {
    pub id: Uuid,
    pub name: String,
    pub provider: Provider,
    pub region: String,
    pub min_replicas: u32,
    pub max_replicas: u32,
    pub desired_replicas: u32,
    pub observed_replicas: u32,
    pub hourly_cost_per_replica: f64,
    pub maximum_hourly_spend: Option<f64>,
    pub enabled: bool,
    pub version: u64,
    pub last_scaled_at: Option<DateTime<Utc>>,
    pub created_at: DateTime<Utc>,
}

impl Fleet {
    pub fn new(spec: FleetSpec, now: DateTime<Utc>) -> Result<Self, DomainError> {
        spec.validate()?;
        Ok(Self {
            id: Uuid::new_v4(), name: spec.name, provider: Provider::Simulation,
            region: spec.region, min_replicas: spec.min_replicas,
            max_replicas: spec.max_replicas,
            desired_replicas: spec.desired_replicas,
            observed_replicas: spec.desired_replicas,
            hourly_cost_per_replica: spec.hourly_cost_per_replica,
            maximum_hourly_spend: spec.maximum_hourly_spend,
            enabled: true, version: 0, last_scaled_at: None, created_at: now,
        })
    }

    pub fn hourly_spend(&self, replicas: u32) -> f64 {
        replicas as f64 * self.hourly_cost_per_replica
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Policy {
    pub fleet_id: Uuid,
    pub revision: u64,
    pub cpu_scale_out_pct: f64,
    pub cpu_scale_in_pct: f64,
    pub memory_scale_out_pct: f64,
    pub memory_scale_in_pct: f64,
    pub cpu_target_pct: f64,
    pub memory_target_pct: f64,
    pub target_queue_per_replica: u64,
    pub min_samples: usize,
    pub window_seconds: i64,
    pub cooldown_seconds: i64,
    pub max_step_up: u32,
    pub max_step_down: u32,
    pub allow_scale_in: bool,
}

impl Policy {
    pub fn default_for(fleet_id: Uuid) -> Self {
        Self {
            fleet_id, revision: 1,
            cpu_scale_out_pct: 75.0, cpu_scale_in_pct: 25.0,
            memory_scale_out_pct: 85.0, memory_scale_in_pct: 35.0,
            cpu_target_pct: 65.0, memory_target_pct: 70.0,
            target_queue_per_replica: 40,
            min_samples: 3, window_seconds: 300, cooldown_seconds: 120,
            max_step_up: 3, max_step_down: 1, allow_scale_in: true,
        }
    }

    pub fn validate(&self) -> Result<(), DomainError> {
        for (name, value) in [
            ("cpu_scale_out_pct", self.cpu_scale_out_pct),
            ("cpu_scale_in_pct", self.cpu_scale_in_pct),
            ("memory_scale_out_pct", self.memory_scale_out_pct),
            ("memory_scale_in_pct", self.memory_scale_in_pct),
            ("cpu_target_pct", self.cpu_target_pct),
            ("memory_target_pct", self.memory_target_pct),
        ] {
            if !value.is_finite() || !(1.0..=100.0).contains(&value) {
                return Err(DomainError::Invalid(format!("{name} must be finite and between 1 and 100")));
            }
        }
        if self.cpu_scale_in_pct >= self.cpu_scale_out_pct || self.memory_scale_in_pct >= self.memory_scale_out_pct {
            return Err(DomainError::Invalid("scale-in threshold must be below scale-out threshold".into()));
        }
        if self.cpu_target_pct > self.cpu_scale_out_pct || self.memory_target_pct > self.memory_scale_out_pct {
            return Err(DomainError::Invalid("utilization targets must not exceed scale-out thresholds".into()));
        }
        if self.target_queue_per_replica == 0 || self.target_queue_per_replica > 1_000_000_000 {
            return Err(DomainError::Invalid("target_queue_per_replica must be in 1..=1e9".into()));
        }
        if !(2..=120).contains(&self.min_samples) || !(30..=86_400).contains(&self.window_seconds) {
            return Err(DomainError::Invalid("min_samples must be 2..=120 and window_seconds 30..=86400".into()));
        }
        if !(0..=86_400).contains(&self.cooldown_seconds) {
            return Err(DomainError::Invalid("cooldown_seconds must be 0..=86400".into()));
        }
        if !(1..=10_000).contains(&self.max_step_up) || !(1..=10_000).contains(&self.max_step_down) {
            return Err(DomainError::Invalid("scaling steps must be between 1 and 10000".into()));
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetricSample {
    pub id: Uuid,
    pub fleet_id: Uuid,
    pub sampled_at: DateTime<Utc>,
    pub cpu_pct: f64,
    pub memory_pct: f64,
    pub queue_depth: u64,
    pub requests_per_second: f64,
}

impl MetricSample {
    pub fn validate(&self, fleet_id: Uuid, now: DateTime<Utc>) -> Result<(), DomainError> {
        if self.fleet_id != fleet_id {
            return Err(DomainError::Invalid("metric fleet_id mismatch".into()));
        }
        if self.sampled_at > now + chrono::Duration::seconds(30) {
            return Err(DomainError::Invalid("metric timestamp too far in the future".into()));
        }
        if self.sampled_at < now - chrono::Duration::days(7) {
            return Err(DomainError::Invalid("metric timestamp older than 7 days".into()));
        }
        if !self.cpu_pct.is_finite() || !(0.0..=100.0).contains(&self.cpu_pct) {
            return Err(DomainError::Invalid("cpu_pct must be between 0 and 100".into()));
        }
        if !self.memory_pct.is_finite() || !(0.0..=100.0).contains(&self.memory_pct) {
            return Err(DomainError::Invalid("memory_pct must be between 0 and 100".into()));
        }
        if !self.requests_per_second.is_finite() || !(0.0..=1_000_000_000.0).contains(&self.requests_per_second) {
            return Err(DomainError::Invalid("requests_per_second must be finite and nonnegative".into()));
        }
        if self.queue_depth > 1_000_000_000_000 {
            return Err(DomainError::Invalid("queue_depth must be <= 1e12".into()));
        }
        Ok(())
    }
}

#[derive(Debug, Error)]
pub enum DomainError {
    #[error("invalid input: {0}")]
    Invalid(String),
}

#[cfg(test)]
mod tests {
    use super::*;

    fn spec() -> FleetSpec {
        FleetSpec { name: "payments-prod".into(), region: "us-east-1".into(),
            min_replicas: 1, max_replicas: 20, desired_replicas: 3,
            hourly_cost_per_replica: 0.20, maximum_hourly_spend: Some(4.0) }
    }

    #[test] fn valid_spec_passes() { assert!(spec().validate().is_ok()); }
    #[test] fn bad_name_rejected() { let mut s=spec(); s.name="bad name".into(); assert!(s.validate().is_err()); }
    #[test] fn empty_region_rejected() { let mut s=spec(); s.region="".into(); assert!(s.validate().is_err()); }
    #[test] fn zero_min_rejected() { let mut s=spec(); s.min_replicas=0; assert!(s.validate().is_err()); }
    #[test] fn impossible_bounds_rejected() { let mut s=spec(); s.min_replicas=21; assert!(s.validate().is_err()); }
    #[test] fn desired_outside_bounds_rejected() { let mut s=spec(); s.desired_replicas=21; assert!(s.validate().is_err()); }
    #[test] fn nan_cost_rejected() { let mut s=spec(); s.hourly_cost_per_replica=f64::NAN; assert!(s.validate().is_err()); }
    #[test] fn infinite_budget_rejected() { let mut s=spec(); s.maximum_hourly_spend=Some(f64::INFINITY); assert!(s.validate().is_err()); }
    #[test] fn starting_budget_enforced() { let mut s=spec(); s.maximum_hourly_spend=Some(0.01); assert!(s.validate().is_err()); }
    #[test] fn fleet_defaults_to_simulation() { let f=Fleet::new(spec(),Utc::now()).unwrap(); assert_eq!(f.provider,Provider::Simulation); }
    #[test] fn policy_is_valid_by_default() { assert!(Policy::default_for(Uuid::new_v4()).validate().is_ok()); }
    #[test] fn policy_rejects_no_hysteresis() { let mut p=Policy::default_for(Uuid::new_v4()); p.cpu_scale_in_pct=90.0; assert!(p.validate().is_err()); }
    #[test] fn policy_rejects_nan() { let mut p=Policy::default_for(Uuid::new_v4()); p.memory_target_pct=f64::NAN; assert!(p.validate().is_err()); }
    #[test] fn policy_rejects_zero_queue_target() { let mut p=Policy::default_for(Uuid::new_v4()); p.target_queue_per_replica=0; assert!(p.validate().is_err()); }
    #[test] fn policy_rejects_broken_window() { let mut p=Policy::default_for(Uuid::new_v4()); p.window_seconds=10; assert!(p.validate().is_err()); }
    #[test] fn policy_rejects_no_step_up() { let mut p=Policy::default_for(Uuid::new_v4()); p.max_step_up=0; assert!(p.validate().is_err()); }
    #[test] fn metric_future_rejected() { let id=Uuid::new_v4(); let now=Utc::now(); let s=MetricSample {id:Uuid::new_v4(),fleet_id:id,sampled_at:now+chrono::Duration::minutes(1),cpu_pct:50.0,memory_pct:50.0,queue_depth:0,requests_per_second:1.0}; assert!(s.validate(id,now).is_err()); }
    #[test] fn metric_negative_cpu_rejected() { let id=Uuid::new_v4(); let now=Utc::now(); let s=MetricSample {id:Uuid::new_v4(),fleet_id:id,sampled_at:now,cpu_pct:-0.01,memory_pct:50.0,queue_depth:0,requests_per_second:1.0}; assert!(s.validate(id,now).is_err()); }
    #[test] fn metric_cross_fleet_rejected() { let id=Uuid::new_v4(); let now=Utc::now(); let s=MetricSample {id:Uuid::new_v4(),fleet_id:Uuid::new_v4(),sampled_at:now,cpu_pct:50.0,memory_pct:50.0,queue_depth:0,requests_per_second:1.0}; assert!(s.validate(id,now).is_err()); }
}
