//! Stateful policy inputs translated to a pure autoscaling decision.
//!
//! Safety properties:
//! - requires a minimum number of valid fresh samples;
//! - requires a consecutive breach before scaling in either direction;
//! - does not scale when disabled or in cooldown;
//! - never violates configured hard replica limits or hourly budget;
//! - limits each step size and supports deliberate disabling of scale-in;
//! - does not take side effects (the storage layer applies decisions).

use crate::forecast::{linear_forecast, Forecast};
use crate::model::{Fleet, MetricSample, Policy};
use chrono::{DateTime, Duration, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ScaleAction {
    Hold,
    ScaleOut,
    ScaleIn,
    InsufficientData,
    Cooldown,
    BudgetBlocked,
    Disabled,
}

impl ScaleAction {
    pub fn changes_capacity(self) -> bool {
        matches!(self, ScaleAction::ScaleOut | ScaleAction::ScaleIn)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Signals {
    pub smoothed_cpu_pct: f64,
    pub smoothed_memory_pct: f64,
    pub latest_queue_depth: u64,
    pub latest_requests_per_second: f64,
    pub cpu_forecast: Option<Forecast>,
    pub memory_forecast: Option<Forecast>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Evaluation {
    pub fleet_id: Uuid,
    pub evaluated_at: DateTime<Utc>,
    pub action: ScaleAction,
    pub current_replicas: u32,
    pub proposed_replicas: u32,
    pub candidate_replicas: u32,
    pub estimated_hourly_spend: f64,
    pub sample_count: usize,
    pub newest_sample_id: Option<Uuid>,
    pub policy_revision: u64,
    pub signals: Option<Signals>,
    pub reason: String,
}

impl Evaluation {
    fn initial(fleet: &Fleet, policy: &Policy, now: DateTime<Utc>) -> Self {
        Self {
            fleet_id: fleet.id, evaluated_at: now,
            action: ScaleAction::Hold,
            current_replicas: fleet.desired_replicas,
            proposed_replicas: fleet.desired_replicas,
            candidate_replicas: fleet.desired_replicas,
            estimated_hourly_spend: fleet.hourly_spend(fleet.desired_replicas),
            sample_count: 0, newest_sample_id: None,
            policy_revision: policy.revision, signals: None,
            reason: String::new(),
        }
    }

    fn status(mut self, action: ScaleAction, reason: impl Into<String>) -> Self {
        self.action = action;
        self.reason = reason.into();
        self
    }
}

/// Exponentially weighted average: more recent observations matter more.
fn ewma(values: impl IntoIterator<Item = f64>) -> Option<f64> {
    let mut result: Option<f64> = None;
    for x in values {
        result = Some(result.map_or(x, |prev| prev * 0.45 + x * 0.55));
    }
    result
}

/// Saturating ceil division avoids overflow for extreme metrics.
fn ceil_div(a: u64, b: u64) -> u64 {
    a / b + u64::from(a % b != 0)
}

fn projected_capacity(desired: u32, utilization: f64, target: f64) -> u32 {
    let proposed = (desired as f64 * utilization / target).ceil();
    if !proposed.is_finite() || proposed < 0.0 { return desired; }
    proposed.min(u32::MAX as f64) as u32
}

pub fn evaluate(fleet: &Fleet, policy: &Policy, samples: &[MetricSample], now: DateTime<Utc>) -> Evaluation {
    let result = Evaluation::initial(fleet, policy, now);
    if !fleet.enabled { return result.status(ScaleAction::Disabled, "fleet is disabled"); }
    if let Err(error) = policy.validate() {
        return result.status(ScaleAction::InsufficientData, format!("invalid policy: {error}"));
    }
    if policy.fleet_id != fleet.id {
        return result.status(ScaleAction::InsufficientData, "policy fleet mismatch");
    }

    let cutoff = now - Duration::seconds(policy.window_seconds);
    let mut valid: Vec<&MetricSample> = samples.iter().filter(|s| {
        s.fleet_id == fleet.id
            && s.sampled_at >= cutoff
            && s.sampled_at <= now
            && s.cpu_pct.is_finite() && (0.0..=100.0).contains(&s.cpu_pct)
            && s.memory_pct.is_finite() && (0.0..=100.0).contains(&s.memory_pct)
            && s.requests_per_second.is_finite() && s.requests_per_second >= 0.0
    }).collect();
    valid.sort_by_key(|s| (s.sampled_at, s.id));
    let mut result = result;
    result.sample_count = valid.len();
    result.newest_sample_id = valid.last().map(|s| s.id);

    if valid.len() < policy.min_samples {
        return result.status(ScaleAction::InsufficientData, format!(
            "needs {} fresh samples, received {}", policy.min_samples, valid.len()));
    }

    let cpu: Vec<f64> = valid.iter().map(|s| s.cpu_pct).collect();
    let memory: Vec<f64> = valid.iter().map(|s| s.memory_pct).collect();
    let smoothed_cpu = ewma(cpu.iter().copied()).unwrap_or(0.0);
    let smoothed_memory = ewma(memory.iter().copied()).unwrap_or(0.0);
    let latest = valid[valid.len() - 1];
    result.signals = Some(Signals {
        smoothed_cpu_pct: smoothed_cpu,
        smoothed_memory_pct: smoothed_memory,
        latest_queue_depth: latest.queue_depth,
        latest_requests_per_second: latest.requests_per_second,
        cpu_forecast: linear_forecast(&cpu[cpu.len().saturating_sub(16)..]),
        memory_forecast: linear_forecast(&memory[memory.len().saturating_sub(16)..]),
    });

    // Use consecutive breaches, rather than a single outlier, to suppress flapping.
    let tail = &valid[valid.len() - policy.min_samples..];
    let overloaded_cpu = tail.iter().all(|s| s.cpu_pct >= policy.cpu_scale_out_pct);
    let overloaded_memory = tail.iter().all(|s| s.memory_pct >= policy.memory_scale_out_pct);
    let capacity = (fleet.desired_replicas as u64).saturating_mul(policy.target_queue_per_replica);
    let overloaded_queue = tail.iter().all(|s| s.queue_depth > capacity);

    let mut action = ScaleAction::Hold;
    let mut candidate = fleet.desired_replicas;
    let mut reason = "metrics within hysteresis band".to_string();

    if overloaded_cpu || overloaded_memory || overloaded_queue {
        let queue_required = ceil_div(latest.queue_depth, policy.target_queue_per_replica)
            .min(u32::MAX as u64) as u32;
        let cpu_required = if overloaded_cpu {
            projected_capacity(fleet.desired_replicas, smoothed_cpu, policy.cpu_target_pct)
        } else { fleet.desired_replicas };
        let memory_required = if overloaded_memory {
            projected_capacity(fleet.desired_replicas, smoothed_memory, policy.memory_target_pct)
        } else { fleet.desired_replicas };
        candidate = candidate.max(cpu_required).max(memory_required);
        if overloaded_queue { candidate = candidate.max(queue_required); }
        candidate = candidate.max(fleet.desired_replicas.saturating_add(1));
        candidate = candidate.min(fleet.desired_replicas.saturating_add(policy.max_step_up))
            .min(fleet.max_replicas);
        if candidate > fleet.desired_replicas {
            action = ScaleAction::ScaleOut;
            reason = format!("sustained overload: cpu={}, memory={}, queue={}",
                overloaded_cpu, overloaded_memory, overloaded_queue);
        } else {
            reason = "replica ceiling reached".into();
        }
    } else if policy.allow_scale_in && tail.iter().all(|s| {
        s.cpu_pct <= policy.cpu_scale_in_pct && s.memory_pct <= policy.memory_scale_in_pct && s.queue_depth == 0
    }) && smoothed_cpu <= policy.cpu_scale_in_pct && smoothed_memory <= policy.memory_scale_in_pct {
        candidate = fleet.desired_replicas.saturating_sub(policy.max_step_down).max(fleet.min_replicas);
        if candidate < fleet.desired_replicas {
            action = ScaleAction::ScaleIn;
            reason = "sustained low utilization and empty queue".into();
        } else {
            reason = "replica floor reached".into();
        }
    }

    result.candidate_replicas = candidate;
    if !action.changes_capacity() { return result.status(action, reason); }

    if let Some(last_scaled_at) = fleet.last_scaled_at {
        if now.signed_duration_since(last_scaled_at).num_seconds() < policy.cooldown_seconds {
            return result.status(ScaleAction::Cooldown, format!(
                "cooldown active for {} seconds", policy.cooldown_seconds));
        }
    }

    if action == ScaleAction::ScaleOut {
        if let Some(budget) = fleet.maximum_hourly_spend {
            // Protect against floating-point rounding at the spending boundary.
            let budget_replicas = ((budget / fleet.hourly_cost_per_replica) + 1e-9)
                .floor().max(0.0).min(u32::MAX as f64) as u32;
            if budget_replicas <= fleet.desired_replicas {
                return result.status(ScaleAction::BudgetBlocked, "hourly budget prevents scale-out");
            }
            if candidate > budget_replicas {
                candidate = budget_replicas;
                reason.push_str("; step constrained by hourly budget");
            }
        }
    }

    result.proposed_replicas = candidate;
    result.estimated_hourly_spend = fleet.hourly_spend(candidate);
    result.status(action, reason)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{FleetSpec, Policy};

    fn setup() -> (Fleet, Policy, DateTime<Utc>) {
        let now=Utc::now();
        let spec=FleetSpec {name:"api-prod".into(),region:"us-east-1".into(),min_replicas:1,
            max_replicas:20,desired_replicas:3,hourly_cost_per_replica:0.25,maximum_hourly_spend:Some(5.0)};
        let f=Fleet::new(spec,now).unwrap();
        let p=Policy::default_for(f.id);
        (f,p,now)
    }

    fn metrics(f: &Fleet, now: DateTime<Utc>, cpu: f64, memory: f64, queue: u64) -> Vec<MetricSample> {
        (0..4).map(|i| MetricSample {id:Uuid::new_v4(),fleet_id:f.id,
            sampled_at:now-Duration::seconds(40-i*10),cpu_pct:cpu,
            memory_pct:memory,queue_depth:queue,requests_per_second:10.0}).collect()
    }

    #[test] fn no_samples_means_insufficient() { let (f,p,n)=setup(); assert_eq!(evaluate(&f,&p,&[],n).action,ScaleAction::InsufficientData); }
    #[test] fn one_sample_does_not_trigger() { let (f,p,n)=setup(); let m=metrics(&f,n,95.0,95.0,1000); assert_eq!(evaluate(&f,&p,&m[..1],n).action,ScaleAction::InsufficientData); }
    #[test] fn normal_load_holds() { let (f,p,n)=setup(); assert_eq!(evaluate(&f,&p,&metrics(&f,n,55.0,55.0,0),n).action,ScaleAction::Hold); }
    #[test] fn cpu_overload_scales_out() { let (f,p,n)=setup(); let d=evaluate(&f,&p,&metrics(&f,n,92.0,55.0,0),n); assert_eq!(d.action,ScaleAction::ScaleOut); assert!(d.proposed_replicas>3); }
    #[test] fn memory_overload_scales_out() { let (f,p,n)=setup(); assert_eq!(evaluate(&f,&p,&metrics(&f,n,40.0,94.0,0),n).action,ScaleAction::ScaleOut); }
    #[test] fn queue_overload_scales_out() { let (f,p,n)=setup(); assert_eq!(evaluate(&f,&p,&metrics(&f,n,40.0,40.0,200),n).action,ScaleAction::ScaleOut); }
    #[test] fn sustained_low_load_scales_in() { let (f,p,n)=setup(); let d=evaluate(&f,&p,&metrics(&f,n,8.0,8.0,0),n); assert_eq!(d.action,ScaleAction::ScaleIn); assert_eq!(d.proposed_replicas,2); }
    #[test] fn single_spike_does_not_scale_out() { let (f,p,n)=setup(); let mut m=metrics(&f,n,40.0,40.0,0); m.last_mut().unwrap().cpu_pct=100.0; assert_eq!(evaluate(&f,&p,&m,n).action,ScaleAction::Hold); }
    #[test] fn single_dip_does_not_scale_in() { let (f,p,n)=setup(); let mut m=metrics(&f,n,50.0,50.0,0); m.last_mut().unwrap().cpu_pct=1.0; assert_eq!(evaluate(&f,&p,&m,n).action,ScaleAction::Hold); }
    #[test] fn disabled_fleet_holds() { let (mut f,p,n)=setup(); f.enabled=false; assert_eq!(evaluate(&f,&p,&metrics(&f,n,99.0,99.0,300),n).action,ScaleAction::Disabled); }
    #[test] fn cooldown_blocks_changes() { let (mut f,p,n)=setup(); f.last_scaled_at=Some(n-Duration::seconds(3)); assert_eq!(evaluate(&f,&p,&metrics(&f,n,99.0,99.0,0),n).action,ScaleAction::Cooldown); }
    #[test] fn expired_cooldown_allows_changes() { let (mut f,p,n)=setup(); f.last_scaled_at=Some(n-Duration::seconds(300)); assert_eq!(evaluate(&f,&p,&metrics(&f,n,99.0,99.0,0),n).action,ScaleAction::ScaleOut); }
    #[test] fn min_replicas_respected() { let (mut f,p,n)=setup(); f.desired_replicas=1; let d=evaluate(&f,&p,&metrics(&f,n,1.0,1.0,0),n); assert_eq!(d.action,ScaleAction::Hold); assert_eq!(d.proposed_replicas,1); }
    #[test] fn max_replicas_respected() { let (mut f,p,n)=setup(); f.desired_replicas=20; let d=evaluate(&f,&p,&metrics(&f,n,99.0,99.0,9999),n); assert_eq!(d.action,ScaleAction::Hold); assert_eq!(d.proposed_replicas,20); }
    #[test] fn scale_out_step_respected() { let (f,p,n)=setup(); let d=evaluate(&f,&p,&metrics(&f,n,99.0,99.0,9999),n); assert_eq!(d.proposed_replicas,6); }
    #[test] fn scale_in_step_respected() { let (f,p,n)=setup(); let d=evaluate(&f,&p,&metrics(&f,n,0.0,0.0,0),n); assert_eq!(d.proposed_replicas,2); }
    #[test] fn budget_blocks_scale_out() { let (mut f,p,n)=setup(); f.maximum_hourly_spend=Some(0.75); assert_eq!(evaluate(&f,&p,&metrics(&f,n,99.0,99.0,0),n).action,ScaleAction::BudgetBlocked); }
    #[test] fn budget_limits_step() { let (mut f,p,n)=setup(); f.maximum_hourly_spend=Some(1.0); let d=evaluate(&f,&p,&metrics(&f,n,99.0,99.0,0),n); assert_eq!(d.proposed_replicas,4); }
    #[test] fn scale_in_can_be_disabled() { let (f,mut p,n)=setup(); p.allow_scale_in=false; assert_eq!(evaluate(&f,&p,&metrics(&f,n,0.0,0.0,0),n).action,ScaleAction::Hold); }
    #[test] fn stale_samples_ignored() { let (f,p,n)=setup(); let mut m=metrics(&f,n,99.0,99.0,0); for s in &mut m {s.sampled_at=n-Duration::minutes(60);} assert_eq!(evaluate(&f,&p,&m,n).action,ScaleAction::InsufficientData); }
    #[test] fn future_samples_ignored() { let (f,p,n)=setup(); let mut m=metrics(&f,n,99.0,99.0,0); for s in &mut m {s.sampled_at=n+Duration::minutes(2);} assert_eq!(evaluate(&f,&p,&m,n).action,ScaleAction::InsufficientData); }
    #[test] fn wrong_fleet_samples_ignored() { let (f,p,n)=setup(); let mut m=metrics(&f,n,99.0,99.0,0); for s in &mut m {s.fleet_id=Uuid::new_v4();} assert_eq!(evaluate(&f,&p,&m,n).action,ScaleAction::InsufficientData); }
    #[test] fn nan_samples_ignored() { let (f,p,n)=setup(); let mut m=metrics(&f,n,99.0,99.0,0); for s in &mut m {s.cpu_pct=f64::NAN;} assert_eq!(evaluate(&f,&p,&m,n).action,ScaleAction::InsufficientData); }
    #[test] fn zero_queue_target_protected_by_validation() { let (f,mut p,n)=setup(); p.target_queue_per_replica=1; assert_eq!(evaluate(&f,&p,&metrics(&f,n,40.0,40.0,15),n).action,ScaleAction::ScaleOut); }
    #[test] fn queued_work_prevents_scale_in() { let (f,p,n)=setup(); assert_eq!(evaluate(&f,&p,&metrics(&f,n,1.0,1.0,1),n).action,ScaleAction::Hold); }
    #[test] fn policy_mismatch_is_rejected() { let (f,mut p,n)=setup(); p.fleet_id=Uuid::new_v4(); assert_eq!(evaluate(&f,&p,&metrics(&f,n,99.0,99.0,0),n).action,ScaleAction::InsufficientData); }
    #[test] fn invalid_policy_does_not_panic() { let (f,mut p,n)=setup(); p.target_queue_per_replica=0; assert_eq!(evaluate(&f,&p,&metrics(&f,n,99.0,99.0,1000),n).action,ScaleAction::InsufficientData); }
    #[test] fn decision_has_forecast() { let (f,p,n)=setup(); let d=evaluate(&f,&p,&metrics(&f,n,50.0,50.0,0),n); assert!(d.signals.unwrap().cpu_forecast.is_some()); }
    #[test] fn ceil_div_is_saturating_safe() { assert_eq!(ceil_div(u64::MAX,1),u64::MAX); }
}
