//! Pure, deterministic CloudScale domain model and autoscaling evaluator.
//!
//! The core crate does not access the network, environment, filesystem, or database.
//! `evaluate` takes explicit inputs and an explicit clock, making decisions
//! independently reproducible in unit tests and incident postmortems.

pub mod evaluate;
pub mod forecast;
pub mod model;

pub use evaluate::{evaluate, Evaluation, ScaleAction, Signals};
pub use forecast::{linear_forecast, linear_slope, Forecast};
pub use model::{DomainError, Fleet, FleetSpec, MetricSample, Policy, Provider};
