//! Best-effort linear trend forecasting for dashboard observability.
//! Forecasts are advisory and do not independently trigger scaling.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Forecast {
    pub estimated_next: f64,
    pub slope_per_interval: f64,
    pub observed_points: usize,
    pub coefficient_of_determination: f64,
}

/// Ordinary least-squares fit of a uniformly spaced scalar sequence.
/// No fit is returned for fewer than three points or for nonfinite input.
pub fn linear_slope(values: &[f64]) -> Option<(f64, f64)> {
    if values.len() < 3 || values.iter().any(|x| !x.is_finite()) {
        return None;
    }
    let n = values.len() as f64;
    let x_bar = (n - 1.0) / 2.0;
    let y_bar = values.iter().sum::<f64>() / n;
    let mut xx = 0.0;
    let mut xy = 0.0;
    for (i, &y) in values.iter().enumerate() {
        let dx = i as f64 - x_bar;
        xx += dx * dx;
        xy += dx * (y - y_bar);
    }
    if xx <= f64::EPSILON { return None; }
    let slope = xy / xx;
    let intercept = y_bar - slope * x_bar;
    Some((slope, intercept))
}

pub fn linear_forecast(values: &[f64]) -> Option<Forecast> {
    let (slope, intercept) = linear_slope(values)?;
    let mean = values.iter().sum::<f64>() / values.len() as f64;
    let total = values.iter().map(|v| (v - mean).powi(2)).sum::<f64>();
    let residual = values.iter().enumerate().map(|(i, v)| {
        (v - (intercept + i as f64 * slope)).powi(2)
    }).sum::<f64>();
    let r2 = if total <= f64::EPSILON { 1.0 } else { (1.0 - residual / total).clamp(0.0, 1.0) };
    Some(Forecast { estimated_next: intercept + values.len() as f64 * slope,
        slope_per_interval: slope, observed_points: values.len(),
        coefficient_of_determination: r2 })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn perfect_linear_trend() {
        let f = linear_forecast(&[1.0,2.0,3.0,4.0]).unwrap();
        assert!((f.estimated_next-5.0).abs()<1e-9);
        assert!((f.coefficient_of_determination-1.0).abs()<1e-9);
    }
    #[test] fn flat_series_is_flat() {
        let f=linear_forecast(&[7.0,7.0,7.0,7.0]).unwrap();
        assert!((f.estimated_next-7.0).abs()<1e-9);
    }
    #[test] fn declining_series() { assert!(linear_forecast(&[50.0,40.0,30.0]).unwrap().slope_per_interval<0.0); }
    #[test] fn insufficient_data() { assert!(linear_forecast(&[1.0,2.0]).is_none()); }
    #[test] fn nan_data() { assert!(linear_forecast(&[1.0,f64::NAN,3.0]).is_none()); }
    #[test] fn infinity_data() { assert!(linear_forecast(&[1.0,f64::INFINITY,3.0]).is_none()); }
    #[test] fn noisy_series_has_poorer_fit() { assert!(linear_forecast(&[2.0,8.0,1.0,9.0,3.0]).unwrap().coefficient_of_determination<0.9); }
}
