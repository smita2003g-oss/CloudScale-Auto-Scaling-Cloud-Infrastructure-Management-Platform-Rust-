//! Deterministic property-style checks without arbitrary external data.
//! These tests exercise thousands of policy combinations and guardrails.

use chrono::{DateTime, Duration, Utc};
use cloudscale_core::{evaluate, Fleet, FleetSpec, MetricSample, Policy, ScaleAction};
use uuid::Uuid;

fn fixture(desired:u32,max:u32,cost:f64,budget:Option<f64>) -> (Fleet,Policy,DateTime<Utc>) {
    let now=Utc::now();
    let f=Fleet::new(FleetSpec {name:"load-test".into(),region:"us-east-1".into(),
        min_replicas:1,max_replicas:max,desired_replicas:desired,
        hourly_cost_per_replica:cost,maximum_hourly_spend:budget},now).unwrap();
    let p=Policy::default_for(f.id);
    (f,p,now)
}
fn signals(f:&Fleet,now:DateTime<Utc>,cpu:f64,memory:f64,queue:u64) -> Vec<MetricSample> {
    (0..5).map(|i|MetricSample {id:Uuid::new_v4(),fleet_id:f.id,
        sampled_at:now-Duration::seconds((5-i)*10),cpu_pct:cpu,
        memory_pct:memory,queue_depth:queue,requests_per_second:100.0}).collect()
}

#[test]
fn capacity_always_stays_within_hard_bounds() {
    let mut tested=0;
    for desired in 1..=25 {
        for cpu in (0..=100).step_by(5) {
            for memory in (0..=100).step_by(10) {
                for queue in [0,1,100,10_000] {
                    let (f,p,now)=fixture(desired,30,0.01,None);
                    let d=evaluate(&f,&p,&signals(&f,now,cpu as f64,memory as f64,queue),now);
                    assert!(d.proposed_replicas >= f.min_replicas);
                    assert!(d.proposed_replicas <= f.max_replicas);
                    tested+=1;
                }
            }
        }
    }
    assert_eq!(tested,25*21*11*4);
}

#[test]
fn scale_out_never_exceeds_step_limit() {
    for desired in 1..=40 {
        let (f,p,now)=fixture(desired,50,0.01,None);
        let d=evaluate(&f,&p,&signals(&f,now,100.0,100.0,100_000),now);
        assert!(d.proposed_replicas <= desired+p.max_step_up);
        assert!(d.proposed_replicas >= desired);
    }
}

#[test]
fn scale_in_never_exceeds_step_limit() {
    for desired in 1..=40 {
        let (f,p,now)=fixture(desired,50,0.01,None);
        let d=evaluate(&f,&p,&signals(&f,now,0.0,0.0,0),now);
        assert!(d.proposed_replicas >= desired.saturating_sub(p.max_step_down));
        assert!(d.proposed_replicas <= desired);
    }
}

#[test]
fn budgets_never_exceeded_after_decision() {
    for budget_replicas in 3..=20 {
        for load in (0..=100).step_by(5) {
            let cost=0.40;
            let budget=budget_replicas as f64 * cost;
            let (f,p,now)=fixture(3,40,cost,Some(budget));
            let d=evaluate(&f,&p,&signals(&f,now,load as f64,95.0,99999),now);
            assert!(d.estimated_hourly_spend <= budget+1e-9);
            assert!(d.proposed_replicas as f64 * cost <= budget+1e-9);
        }
    }
}

#[test]
fn chronological_order_of_inputs_is_irrelevant() {
    let (f,p,now)=fixture(4,20,0.1,None);
    let mut s=signals(&f,now,95.0,95.0,10000);
    let first=evaluate(&f,&p,&s,now);
    s.reverse();
    let second=evaluate(&f,&p,&s,now);
    assert_eq!(first.action,second.action);
    assert_eq!(first.proposed_replicas,second.proposed_replicas);
}

#[test]
fn disabled_fleets_never_change_capacity() {
    for load in (0..=100).step_by(10) {
        let (mut f,p,now)=fixture(5,20,0.1,None);
        f.enabled=false;
        let d=evaluate(&f,&p,&signals(&f,now,load as f64,load as f64,999),now);
        assert_eq!(d.proposed_replicas,5);
        assert_eq!(d.action,ScaleAction::Disabled);
    }
}

#[test]
fn cooldown_never_permits_scaling() {
    for seconds in 0..120 {
        let (mut f,p,now)=fixture(5,20,0.1,None);
        f.last_scaled_at=Some(now-Duration::seconds(seconds));
        let d=evaluate(&f,&p,&signals(&f,now,95.0,95.0,999),now);
        assert_eq!(d.action,ScaleAction::Cooldown);
        assert_eq!(d.proposed_replicas,5);
    }
}

#[test]
fn insufficient_fresh_samples_cannot_scale() {
    let (f,p,now)=fixture(4,20,0.1,None);
    let samples=signals(&f,now,100.0,100.0,1000);
    for count in 0..p.min_samples {
        let d=evaluate(&f,&p,&samples[..count],now);
        assert_eq!(d.action,ScaleAction::InsufficientData);
        assert_eq!(d.current_replicas,d.proposed_replicas);
    }
}

#[test]
fn a_single_spike_never_triggers_scale_out() {
    let (f,p,now)=fixture(3,20,0.1,None);
    let mut samples=signals(&f,now,40.0,40.0,0);
    let newest=samples.last_mut().unwrap();
    newest.cpu_pct=100.0;
    newest.memory_pct=100.0;
    newest.queue_depth=10000;
    let d=evaluate(&f,&p,&samples,now);
    assert_eq!(d.action,ScaleAction::Hold);
}

#[test]
fn a_single_dip_never_triggers_scale_in() {
    let (f,p,now)=fixture(3,20,0.1,None);
    let mut samples=signals(&f,now,50.0,50.0,0);
    let newest=samples.last_mut().unwrap();
    newest.cpu_pct=0.0;
    newest.memory_pct=0.0;
    let d=evaluate(&f,&p,&samples,now);
    assert_eq!(d.action,ScaleAction::Hold);
}

#[test]
fn scale_out_cost_is_never_lower_than_baseline() {
    let (f,p,now)=fixture(3,20,0.1,None);
    let d=evaluate(&f,&p,&signals(&f,now,99.0,99.0,500),now);
    assert_eq!(d.action,ScaleAction::ScaleOut);
    assert!(d.estimated_hourly_spend>=f.hourly_spend(3));
}

#[test]
fn scale_in_cost_is_never_higher_than_baseline() {
    let (f,p,now)=fixture(3,20,0.1,None);
    let d=evaluate(&f,&p,&signals(&f,now,0.0,0.0,0),now);
    assert_eq!(d.action,ScaleAction::ScaleIn);
    assert!(d.estimated_hourly_spend<=f.hourly_spend(3));
}
