//! CloudScale application service: coordination between deterministic domain
//! rules and persisted fleet/metric/decision records.

use chrono::{DateTime, Duration, Utc};
use cloudscale_core::{evaluate, DomainError, Evaluation, Fleet, FleetSpec, MetricSample, Policy};
use cloudscale_store::{Store, StoreError};
use serde::{Deserialize, Serialize};
use thiserror::Error;
use uuid::Uuid;

#[derive(Debug, Error)]
pub enum EngineError {
    #[error(transparent)]
    Domain(#[from] DomainError),
    #[error(transparent)]
    Storage(#[from] StoreError),
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct MetricInput {
    pub cpu_pct: f64,
    pub memory_pct: f64,
    pub queue_depth: u64,
    pub requests_per_second: f64,
    /// A producer should provide timestamps for event-time correctness.
    /// If omitted, ingestion time is used.
    pub sampled_at: Option<DateTime<Utc>>,
    /// Allows monitoring agents to safely retry the same measurement.
    pub sample_id: Option<Uuid>,
}

#[derive(Debug, Clone, Serialize)]
pub struct RunOutcome {
    pub evaluation: Evaluation,
    /// false for an already-seen input or policy revision.
    pub recorded: bool,
    pub observed_fleet: Fleet,
}

#[derive(Clone)]
pub struct Engine {
    store: Store,
}

impl Engine {
    pub fn new(store: Store) -> Self { Self { store } }
    pub fn store(&self) -> &Store { &self.store }

    pub async fn create_fleet(&self,spec:FleetSpec,now:DateTime<Utc>) -> Result<Fleet,EngineError> {
        let fleet = Fleet::new(spec,now)?;
        let policy = Policy::default_for(fleet.id);
        self.store.create_fleet(&fleet,&policy).await?;
        Ok(fleet)
    }

    pub async fn record_metric(&self,fleet_id:Uuid,input:MetricInput,now:DateTime<Utc>) -> Result<MetricSample,EngineError> {
        // Explicit existence check allows a helpful 404 instead of an opaque FK violation.
        self.store.get_fleet(fleet_id).await?;
        let sample=MetricSample { id:input.sample_id.unwrap_or_else(Uuid::new_v4),
            fleet_id, sampled_at:input.sampled_at.unwrap_or(now),
            cpu_pct:input.cpu_pct, memory_pct:input.memory_pct,
            queue_depth:input.queue_depth, requests_per_second:input.requests_per_second };
        sample.validate(fleet_id,now)?;
        self.store.insert_metric(&sample).await?;
        Ok(sample)
    }

    pub async fn replace_policy(&self,fleet_id:Uuid,policy:Policy,actor:&str,now:DateTime<Utc>) -> Result<Policy,EngineError> {
        if policy.fleet_id != fleet_id {return Err(DomainError::Invalid("policy fleet_id must match path".into()).into());}
        policy.validate()?;
        self.store.get_fleet(fleet_id).await?;
        Ok(self.store.replace_policy(&policy,actor,now).await?)
    }

    pub async fn preview(&self,fleet_id:Uuid,now:DateTime<Utc>) -> Result<Evaluation,EngineError> {
        let fleet=self.store.get_fleet(fleet_id).await?;
        let policy=self.store.get_policy(fleet_id).await?;
        let from=now-Duration::seconds(policy.window_seconds);
        let samples=self.store.recent_metrics(fleet_id,from,2000).await?;
        Ok(evaluate(&fleet,&policy,&samples,now))
    }

    /// Apply one policy decision. SQLite transaction guarantees journal and
    /// replica update happen together; stale policy/replica version is rejected.
    pub async fn run_once(&self,fleet_id:Uuid,now:DateTime<Utc>) -> Result<RunOutcome,EngineError> {
        let fleet=self.store.get_fleet(fleet_id).await?;
        let policy=self.store.get_policy(fleet_id).await?;
        let from=now-Duration::seconds(policy.window_seconds);
        let samples=self.store.recent_metrics(fleet_id,from,2000).await?;
        let evaluation=evaluate(&fleet,&policy,&samples,now);
        let recorded=self.store.commit_decision(&fleet,&evaluation).await?;
        let observed_fleet=self.store.get_fleet(fleet_id).await?;
        Ok(RunOutcome { evaluation, recorded, observed_fleet })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cloudscale_core::ScaleAction;

    fn spec() -> FleetSpec {
        FleetSpec {name:"checkout-prod".into(),region:"eu-west-1".into(),min_replicas:1,
            max_replicas:10,desired_replicas:2,hourly_cost_per_replica:0.5,
            maximum_hourly_spend:Some(3.5)}
    }
    async fn setup() -> (Engine,Fleet,DateTime<Utc>) {
        let now=Utc::now();
        let engine=Engine::new(Store::open("sqlite::memory:").await.unwrap());
        let fleet=engine.create_fleet(spec(),now).await.unwrap();
        (engine,fleet,now)
    }
    async fn add_metrics(e:&Engine,f:&Fleet,n:DateTime<Utc>,cpu:f64,memory:f64,queue:u64) {
        for i in 0..4 {
            let input=MetricInput { cpu_pct:cpu,memory_pct:memory,queue_depth:queue,
                requests_per_second:20.0,sampled_at:Some(n-Duration::seconds(40-i*10)),sample_id:None };
            e.record_metric(f.id,input,n).await.unwrap();
        }
    }

    #[tokio::test] async fn create_sets_default_policy() { let (e,f,_)=setup().await; assert_eq!(e.store.get_policy(f.id).await.unwrap().fleet_id,f.id); }
    #[tokio::test] async fn preview_is_read_only() { let (e,f,n)=setup().await; add_metrics(&e,&f,n,99.0,90.0,0).await; let d=e.preview(f.id,n).await.unwrap(); assert_eq!(d.action,ScaleAction::ScaleOut); assert_eq!(e.store.get_fleet(f.id).await.unwrap().desired_replicas,2); }
    #[tokio::test] async fn run_once_changes_simulated_fleet() { let (e,f,n)=setup().await; add_metrics(&e,&f,n,99.0,90.0,0).await; let d=e.run_once(f.id,n).await.unwrap(); assert!(d.recorded); assert!(d.observed_fleet.desired_replicas>2); assert_eq!(d.observed_fleet.desired_replicas,d.observed_fleet.observed_replicas); }
    #[tokio::test] async fn same_signal_records_once() { let (e,f,n)=setup().await; add_metrics(&e,&f,n,99.0,90.0,0).await; assert!(e.run_once(f.id,n).await.unwrap().recorded); assert!(!e.run_once(f.id,n).await.unwrap().recorded); }
    #[tokio::test] async fn no_data_records_once() { let (e,f,n)=setup().await; let first=e.run_once(f.id,n).await.unwrap(); assert_eq!(first.evaluation.action,ScaleAction::InsufficientData); assert!(!e.run_once(f.id,n).await.unwrap().recorded); }
    #[tokio::test] async fn invalid_metric_is_rejected() { let (e,f,n)=setup().await; let x=MetricInput {cpu_pct:101.0,memory_pct:2.0,queue_depth:0,requests_per_second:1.0,sampled_at:None,sample_id:None}; assert!(matches!(e.record_metric(f.id,x,n).await,Err(EngineError::Domain(_)))); }
    #[tokio::test] async fn policy_version_is_monotonic() { let (e,f,n)=setup().await; let old=e.store.get_policy(f.id).await.unwrap(); let new=e.replace_policy(f.id,old.clone(),"test",n).await.unwrap(); assert_eq!(new.revision,old.revision+1); }
    #[tokio::test] async fn path_and_policy_mismatch_rejected() { let (e,f,n)=setup().await; let mut p=e.store.get_policy(f.id).await.unwrap(); p.fleet_id=Uuid::new_v4(); assert!(e.replace_policy(f.id,p,"test",n).await.is_err()); }
    #[tokio::test] async fn extreme_load_respects_budget() { let (e,f,n)=setup().await; add_metrics(&e,&f,n,99.0,99.0,100000).await; let d=e.run_once(f.id,n).await.unwrap(); assert!(d.observed_fleet.hourly_spend(d.observed_fleet.desired_replicas)<=3.5); }
}
