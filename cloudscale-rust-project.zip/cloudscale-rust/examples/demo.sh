#!/usr/bin/env bash
# End-to-end demonstration of a simulation fleet and scaling preview.
set -euo pipefail
BASE="${CLOUDSCALE_URL:-http://127.0.0.1:8080}"
: "${CLOUDSCALE_API_KEY:?Set CLOUDSCALE_API_KEY}"
command -v jq >/dev/null || { echo 'jq is required for this demo' >&2; exit 1; }
HEADERS=(-H "x-api-key: ${CLOUDSCALE_API_KEY}" -H 'Content-Type: application/json')
FLEET=$(curl --fail-with-body -sS "${BASE}/v1/fleets" "${HEADERS[@]}" -d '{
  "name":"checkout-simulation","region":"us-east-1","min_replicas":1,
  "max_replicas":12,"desired_replicas":2,"hourly_cost_per_replica":0.25,
  "maximum_hourly_spend":2.0
}')
ID=$(jq -r '.id' <<< "$FLEET")
echo "Created simulated fleet: $ID"
for i in 1 2 3 4; do
  curl --fail-with-body -sS -o /dev/null "${BASE}/v1/fleets/${ID}/metrics" \
    "${HEADERS[@]}" -d '{"cpu_pct":95,"memory_pct":90,"queue_depth":400,"requests_per_second":200}'
  # Interval need not exceed a second because the evaluator validates timestamps,
  # but true production agents should sample over realistic windows.
  sleep 1
done
printf 'Preview (no mutation):\n'
curl --fail-with-body -sS "${BASE}/v1/fleets/${ID}/preview" "${HEADERS[@]}" | jq .
printf 'Apply one simulation decision:\n'
curl --fail-with-body -sS -X POST "${BASE}/v1/fleets/${ID}/run" "${HEADERS[@]}" | jq .
printf 'Audit history:\n'
curl --fail-with-body -sS "${BASE}/v1/fleets/${ID}/audit" "${HEADERS[@]}" | jq .
