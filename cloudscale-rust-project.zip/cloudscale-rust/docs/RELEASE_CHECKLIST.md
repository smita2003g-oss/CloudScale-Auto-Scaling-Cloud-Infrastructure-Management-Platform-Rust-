# Release checklist — all checks require real evidence

- [ ] Real maintainer identified and source ownership/licensing reviewed
- [ ] GitHub repository created by authorized owner and protected main branch enabled
- [ ] Commit authors/timestamps and PR links independently verified
- [ ] `cargo fmt --all -- --check` passes in a linked CI run
- [ ] `cargo clippy --workspace --all-targets -- -D warnings` passes
- [ ] `cargo test --workspace --all-targets` passes, including SQLite tests
- [ ] Full container build and local API smoke demo passes
- [ ] Cost limits, stale metrics, cooldown, idempotency and lease failure cases tested
- [ ] Security threat model reviewed, secret scanning and dependency audit configured
- [ ] Backup and restore drill complete
- [ ] Documentation and API examples match deployed behavior
- [ ] Accuracy of AI contribution disclosure reviewed
- [ ] Real provider integration risk assessed before any cloud API writes

This initial artifact **has not completed** the checklist. Tick boxes only when evidence exists.
