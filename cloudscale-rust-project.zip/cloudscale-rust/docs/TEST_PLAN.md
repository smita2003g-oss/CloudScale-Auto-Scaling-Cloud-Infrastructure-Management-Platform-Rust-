# Test plan and evidence requirements

## Current test sources

1. `crates/cloudscale-core/src/model.rs`: fleet, policy and metric validation tests.
2. `crates/cloudscale-core/src/evaluate.rs`: sustained overload, underload, budgets, cooldown, ceilings, stale and malicious sample filtering.
3. `crates/cloudscale-core/src/forecast.rs`: linear trend forecasting and invalid data handling.
4. `crates/cloudscale-core/tests/invariants.rs`: deterministic loops covering tens of thousands of capacity and safety cases. Each `#[test]` function is one declared test, despite its many assertions.
5. `crates/cloudscale-store/src/lib.rs`: SQLite schema and persistence round trips, duplicate detection, policy revision checks, leases, expired leases, atomic journal.
6. `crates/cloudscale-engine/src/lib.rs`: complete service path from ingestion to simulated capacity change and repeated-run idempotency.
7. `apps/cloudscale-api/src/main.rs`: basic error and UUID conversion tests.

## Run these on a Rust-enabled machine

```bash
cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings
cargo test --workspace --all-targets
python3 scripts/verify.py --ci
bash scripts/verify_independent.sh
python3 scripts/test_sqlite_semantics.py
CLOUDSCALE_API_KEY="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')" docker compose up --build
```

The Docker smoke test requires separate terminals to run `./examples/demo.sh` with the same API key. Check `/readyz` and inspect whether the fleet's simulated desired replicas increase after four overload samples. Restart the controller and verify the same metric ID does not cause another scale event.

## Checks not yet performed

The initial artifact was written in an environment without Rust/Cargo/Docker. The test cases have not been executed here; build, Clippy, rustfmt and container startup are **unverified** until they run on a Rust-capable machine. Static delimiter checks and two independent LOC audits are not equivalent to compilation or test execution.

## Required next phase

- Add real API route integration tests with HTTP clients, bad token, malformed body and concurrency races.
- Run both one-process and two-process SQLite lease contention tests.
- Add provider-contract suites with mocked AWS/Kubernetes adapters.
- Stress at least 100 fleets and 10,000 samples/second in controlled benchmarks; measure database lock contention and p99 latency.
- Test process termination, disk full, corrupted JSON, clock skew, migration failure, partial billing availability and policy rollback.
- Add canary deployment, rollback and security test reports before production use.

Use true CI run URLs and captured logs as release evidence; do not fabricate green badges or test results.
