# Threat model — simulation-only MVP

## Assets and trust boundaries

The HTTP API exposes fleet configuration, telemetry and audit logs. Its only authentication mechanism is a single high-entropy shared API key. SQLite stores all configuration and event history in a local file. External metric senders are untrusted until authenticated. No real cloud resource credentials, provider write permissions or tenant separation exist.

## Threats and mitigations currently present

| Threat | Existing control | Residual exposure |
|---|---|---|
| Unauthenticated writes | Required `x-api-key` for all `/v1/` routes | Shared key is not scoped; rotating it requires coordinated restart |
| Accidental budget overrun | Explicit max hourly spending estimate, hard fleet bounds and step constraints | Estimates are supplied by the user and can differ from actual bills |
| Metrics manipulation | Numeric and timestamp validation, sample minimum and consecutive breach requirements | Any holder of the API key can inject deceptive but valid metrics |
| Repeat apply or race | Unique decision key, optimistic version update and journal transaction | New sample IDs allow additional attempts; SQLite is not multi-host HA |
| Controller crash | Transaction rollback and expiring per-fleet lease | Decisions may be delayed while a lease expires |
| Secret disclosure | `.env` ignored by Git, sanitized generic 500 errors, localhost-default binding | Reverse proxy and TLS deployment configuration absent |
| Database corruption | SQLite constraints, foreign keys, transactional writes | No automatic backups or tested recovery pipeline |
| Unexpected cloud writes | No cloud adapters, only a simulation provider | Real adapters would add substantial new risk |

## Unmitigated risks before public or production deployment

The API has no TLS, rate limits, per-resource authorization, multi-tenant isolation, CSRF analysis for browser clients, secret storage integration, formal audit tamper protection, approval workflow, or WAF. Environment variables can leak via host operator tooling. Logs should never include API keys. Side-channel resistance is only partial: the token comparison is constant time for matching-length byte strings, but an attacker can still observe application-level behavior and key rotation events.

SQLite is not approved here for multi-host deployments using a shared network volume. A root or local filesystem compromise can tamper with audit logs. Infrastructure cost is calculated from a user-supplied static rate, not verified billing data.

## Security acceptance criteria for a future release

- Scoped OIDC identities and per-fleet permissions tested against privilege escalation.
- TLS-only deployments and automatic secret rotation.
- Formal input fuzzing on policy evaluation and JSON decoding; body and request rate limits.
- Verified least-privilege provider credentials and prevention of cross-account operations.
- Multi-host transactional database and tested failure recovery.
- Backups, tamper-evident audit storage, alerting and documented security contact.
- Dependency vulnerability scanner with review and remediation SLA.

No part of this document asserts completion of these future security controls.
