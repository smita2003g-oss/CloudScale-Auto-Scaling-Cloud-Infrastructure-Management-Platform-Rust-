# Running and operating CloudScale

## Developer setup

Install a recent stable Rust toolchain (MSRV declared as 1.82), Cargo, and optionally Docker. Run `mkdir -p data` from the repository root. Define `DATABASE_URL=sqlite://data/cloudscale.db` and `CLOUDSCALE_API_KEY` with at least 24 unpredictable characters. Avoid passing secrets on shared shell command lines or committing `.env` files. Use `cargo run -p cloudscale-api` and, in another terminal, `cargo run -p cloudscale-controller`.

For Docker, copy `.env.example` to `.env`, replace the placeholder key, and execute `docker compose up --build`. The API publishes port 8080 only to loopback. The controller and API share the same named Docker volume for SQLite.

## Startup and readiness

`GET /healthz` confirms the server process is responding. `GET /readyz` confirms the server can query SQLite. A successful health check does **not** certify that autoscaling policies, external telemetry producers or a real cloud adapter are healthy (there are no real cloud adapters).

## Durability and backups

The database is the operational source of truth. SQLite WAL files may coexist with the main database while active. Use the SQLite backup API or temporarily stop writers before copying the volume; do not copy only the main `.db` file while writers are running. Test restores before trusting backups. No automatic backup scheduler exists.

Decisions and audit events are retained indefinitely in the reference release. Metric samples older than 30 days are periodically pruned by the controller. Tune retention only after establishing compliance and storage policy.

## Controller operational behavior

The controller ticks every 15 seconds by default. `CONTROLLER_TICK_SECONDS` accepts values from 2 to 3600. For debugging, `cargo run -p cloudscale-controller -- --once` performs one complete pass and exits. The controller owns a per-process random ID; it obtains a 45-second lease on each fleet. A second controller process using the same local database should skip a fleet already leased.

A controller process terminating before lease release leaves a temporary lock; future controllers recover after the TTL. SQLite errors or rejected stale-policy decisions are logged; the next pass can retry after a fresh evaluation. All capacity writes update only the simulated state.

## Recommended production hardening (not yet implemented)

- Replace the local SQLite repository with a PostgreSQL repository and test multi-host contention.
- Add TLS termination, OAuth/OIDC, per-fleet RBAC, scoped service tokens and audit identity propagation.
- Use audited cloud provider libraries with restricted IAM roles, dry-run support, reconciliation backoff and rollbacks.
- Add request rate limiting, structured metrics, alerting, distributed tracing and SLO monitors.
- Add real traffic replay, load tests, performance profiles, backups, migration rollback, HA drills and disaster recovery evidence.
- Require two-person review for modifying production capacity, maximum spend and provider credentials.

## Troubleshooting

**HTTP 401:** check `x-api-key` and API process environment. **HTTP 400:** inspect JSON fields and policy thresholds; `sampled_at` must not be more than 30 seconds into the future. **Insufficient data:** submit at least `min_samples` samples within the configured window. **No scale-out:** check cooldown, replica maximum and hourly budget. **Conflict:** a concurrent run, policy update or duplicate sample ID was detected; retrieve the latest state before retrying. **Database locked:** ensure the SQLite file is on a local filesystem; reduce concurrent workloads or migrate to a server database.
