# API v1 reference (simulation provider)

Base URL: `http://127.0.0.1:8080` in local development.

All `/v1/` endpoints require `x-api-key: <CLOUDSCALE_API_KEY>`. Missing or incorrect keys return HTTP 401. JSON requests require `Content-Type: application/json`. Error responses have `{"error":"message"}`.

| Method | Path | Meaning |
|---|---|---|
| GET | `/healthz` | Process liveness; intentionally unauthenticated |
| GET | `/readyz` | SQLite readiness; intentionally unauthenticated |
| GET | `/v1/stats` | Fleet count and aggregate simulated hourly cost |
| POST | `/v1/fleets` | Create a simulation fleet and default policy |
| GET | `/v1/fleets` | List fleets |
| GET | `/v1/fleets/:id` | Read a fleet and desired/observed capacity |
| GET | `/v1/fleets/:id/policy` | Fetch current scaling thresholds and revision |
| PUT | `/v1/fleets/:id/policy` | Replace complete policy, increment server-side revision |
| POST | `/v1/fleets/:id/metrics` | Record one metric sample |
| GET | `/v1/fleets/:id/metrics?limit=200` | Recent metric samples |
| GET | `/v1/fleets/:id/preview` | Predict decision without storage mutation |
| POST | `/v1/fleets/:id/run` | Simulate and atomically journal one decision |
| GET | `/v1/fleets/:id/decisions?limit=100` | Recent stored decisions |
| GET | `/v1/fleets/:id/audit?limit=100` | Most recent audit records |

## Fleet creation

Example request body:

```json
{
  "name": "search-prod",
  "region": "us-west-2",
  "min_replicas": 2,
  "max_replicas": 30,
  "desired_replicas": 4,
  "hourly_cost_per_replica": 0.45,
  "maximum_hourly_spend": 10.0
}
```

`name` must be 3–80 ASCII alphanumeric/hyphen/underscore characters; `region` uses the same character set. `min_replicas` must be at least 1 and no larger than max. The desired starting state must satisfy budget, if present. Only the `simulation` provider exists in this release. HTTP 201 returns the complete fleet JSON.

## Metrics ingestion

```json
{
  "cpu_pct": 81.3,
  "memory_pct": 72.0,
  "queue_depth": 110,
  "requests_per_second": 54.5,
  "sampled_at": "2026-10-30T00:00:00Z",
  "sample_id": "5bf385b6-ef52-450e-a126-966bb13f4da5"
}
```

`sampled_at` and `sample_id` are optional. Omitted timestamps use server time; omitted IDs are generated server-side. Do not reuse an ID for a distinct sample. CPU/memory must be finite values 0–100; negative requests and future samples more than 30 seconds ahead are rejected. Timestamps older than 7 days are rejected.

## Policy configuration

First `GET /v1/fleets/:id/policy` to obtain a full policy representation. `PUT` the same object after modifying desired settings. The server requires the supplied `revision` to equal the latest stored revision, then increments it. Stale client updates receive HTTP 409, preventing silent lost updates. Invalid thresholds or mismatched fleet IDs are rejected. Safe defaults:

| Field | Default | Description |
|---|---:|---|
| `cpu_scale_out_pct` | 75 | Sustained CPU overload threshold |
| `cpu_scale_in_pct` | 25 | Sustained low CPU threshold |
| `memory_scale_out_pct` | 85 | Sustained memory overload threshold |
| `memory_scale_in_pct` | 35 | Sustained low memory threshold |
| `cpu_target_pct` | 65 | Scale-out CPU capacity target |
| `memory_target_pct` | 70 | Scale-out memory target |
| `target_queue_per_replica` | 40 | Backlog target per replica |
| `min_samples` | 3 | Consecutive samples required |
| `window_seconds` | 300 | Maximum sample age |
| `cooldown_seconds` | 120 | Minimum time since last change |
| `max_step_up` | 3 | Max replicas added per decision |
| `max_step_down` | 1 | Max replicas removed per decision |
| `allow_scale_in` | true | Manual disabling of scale-in |

## Preview and application

`GET /preview` returns an `Evaluation` object with `action`, `proposed_replicas`, `candidate_replicas`, evidence, cost estimate and explanation. This operation is read-only.

`POST /run` performs the same evaluation and attempts to journal/apply. Its `recorded` boolean reports whether the decision key was newly inserted. With an already processed metric and policy revision, `recorded=false` indicates a deduplicated no-op. For changed capacity, only the simulation state is updated.

## Errors

- 400: invalid UUID, policy, fleet specification or metric
- 401: missing or invalid API key
- 404: missing fleet/policy
- 409: duplicate unique resource or optimistic conflict
- 500: unexpected server failure; details are logged, not sent to the client
- 503: `/readyz` database unavailable

OpenAPI generation, pagination cursor semantics, per-client rate limits, multi-user authorization and formal backward compatibility guarantees are planned but not implemented.
