# Architecture and safety invariants

## Responsibility boundaries

`cloudscale-core` contains the domain model, validation, a pure `evaluate()` function and a small advisory linear regression forecast. It makes no IO calls. This separation permits replaying an historical decision with a fixed clock and unchanged input samples.

`cloudscale-store` owns SQLite persistence, migration, fleet records, policy revisions, metric samples, leases, the decision journal and audit events. `cloudscale-engine` coordinates domain and storage operations. `cloudscale-api` exposes the control plane over authenticated HTTP. `cloudscale-controller` periodically claims short leases, evaluates each fleet, and records decisions.

## Decision procedure

1. Reject disabled fleets and inconsistent policy identities.
2. Collect samples inside the configured look-back window, discarding future or invalid samples.
3. Require `min_samples` fresh samples before considering a change.
4. Compute exponentially weighted averages (EWMA) for CPU and memory.
5. Detect *consecutive* high CPU/memory samples or queue backlog beyond per-replica capacity. A single outlier is not enough.
6. If overloaded, calculate required capacity from utilization targets and queue pressure, then clamp to max-step-up and max-replicas.
7. Otherwise, permit conservative scale-in only when every recent sample shows low CPU, low memory and an empty queue. Respect the scale-in flag and max-step-down.
8. Reject changes during cooldown. For scaling out, stop or constrain changes that would breach the hourly budget.
9. Return a complete, side-effect-free `Evaluation` with evidence and a reason string.

Forecast values are for operator inspection. Forecasting does **not** decide replica count, preventing speculative capacity commitments from an unvalidated model.

## Decision identity and consistency

Decision keys combine `(fleet UUID, policy revision, newest metric sample UUID)`. The journal rejects duplicates using a unique key. A single SQL transaction stores a decision and applies the new replica count, protected by an optimistic version condition on the fleet. If the expected version is stale, the transaction rolls back. A stale policy revision is also rejected, both for scaling decisions and full policy updates.

**Important:** A new sample can trigger another decision after cooldown; the system is not a general exactly-once processing platform. It provides transactional deduplication for identical evaluation inputs. If a client retransmits a metric with a new UUID, it is treated as a new input.

## Lease coordination

Each controller process has an ephemeral owner UUID. Lease acquisition uses a single atomic upsert conditional on expiration or matching ownership. The owner releases after the evaluation; abandoned leases expire after 45 seconds.

**SQLite caveat:** This design permits coordination among processes sharing a **single local SQLite database file**. Do not run it with a shared network filesystem or assume the database supports multi-host replicas. A properly implemented PostgreSQL repository, migrations, adversarial concurrency tests and a real provider reconciler are required for multi-host operation.

## Failure modes

- **Invalid metric:** rejected at ingestion with a client error; never affects the policy window.
- **Missing metric:** result is `insufficient_data`; no capacity change.
- **Repeated sample:** primary-key conflict if the same sample UUID was used.
- **Repeated run:** unique decision key leads to `recorded=false`.
- **Old fleet version:** optimistic conflict; a fresh tick can retry.
- **Old policy revision:** evaluation is rejected, so old rules cannot silently override new rules.
- **Controller crash:** SQLite transaction rolls back; lease expires; future run retries.
- **Budget exceeded by planned scale-out:** either cap at affordable capacity or hold.
- **DB outage/disk full:** run fails and records a warning; no cloud resource is changed.

## Current non-goals

CloudScale does not yet implement Kubernetes HPA, AWS EC2 Auto Scaling, GCP MIG, Azure VM Scale Sets, predictive optimization, SSO, RBAC, multi-tenant isolation, event-driven metrics ingestion, Kafka, Postgres or Terraform provisioning. These are explicitly future features, not hidden functionality.
